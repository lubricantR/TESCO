 python launchteep2.py &
#limitipspeedcalaulatecomm.sh 10000000 0 -- python launchp1.py --model_type=gpt2 --model_name_or_path=openai-community/gpt2 --len_data 64 --length 1 &
python launchp1.py --model_type=gpt2 --model_name_or_path=openai-community/gpt2 --len_data 64 --length 1 &


python launchp0.py --model_type=gpt2 --model_name_or_path=openai-community/gpt2 --len_data 64 --length 1
wait