import torch

def topn_overlap(a: torch.Tensor, b: torch.Tensor, n: int) -> int:
  
   
    if a.ndim != 1 or b.ndim != 1:
        raise ValueError("Input tensors must be 1D")
    if len(a) != len(b):
        raise ValueError("Input tensors must have the same length")
    if n > len(a):
        raise ValueError("n cannot be larger than vector length")

    
    topn_a = torch.topk(a, n).indices
    topn_b = torch.topk(b, n).indices

    
    overlap = set(topn_a.tolist()) & set(topn_b.tolist())
    return len(overlap)
