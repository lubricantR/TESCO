# coding=utf-8
# Modified by SHAFT's team: Private Text Classification on ImageNet-1k.
# 
# Copyright 2022 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Finetuning any 🤗 Transformers model for image classification leveraging 🤗 Accelerate."""

import argparse
import logging
import torch

import datasets
import crypten as ct
from crypten.config import cfg
from multiprocess_launcher import MultiProcessLauncher

from tqdm.auto import tqdm

import transformers
from transformers import AutoConfig, AutoModelForImageClassification
from transformers.utils import check_min_version
from transformers.utils.versions import require_version
import os
import crypten
import crypten.communicator as comm
# Will error if the minimal version of Transformers is not installed. Remove at your own risks.
from crypten.mpc.TESCOltz import TESCO3mul,TESCO3waitall1
from crypten.mpc import MPCTensor


import uuid
from run_generation_private import main,parse_args

if __name__ == "__main__":
    
    args = parse_args()
    
    env = os.environ
    env["WORLD_SIZE"] = '2'
       
    INIT_METHOD = "tcp://127.0.0.1:29500"
    env["RENDEZVOUS"] = INIT_METHOD
    os.environ["RANK"] = '1'
    crypten.init()
    main()
    


