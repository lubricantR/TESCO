python run_image_classification_private.py \
    --model_name_or_path google/vit-base-patch16-224 \
    --max_eval_samples 1 \
    --comp \
    --seed 42