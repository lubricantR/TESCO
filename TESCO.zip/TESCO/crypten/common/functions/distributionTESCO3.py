import numpy as np

# ---configure ---
BUFFER_SIZE = 1_000_0
DTYPE = np.float32
OUTPUT_FILE_PATTERN = "gpt2{:03d}.dat"

# --- state ---
buffer = np.empty(BUFFER_SIZE, dtype=DTYPE)
index = 0
file_count = 0

def collect_tensor(t):

    global index, file_count
    flat_vals = np.asarray(t, dtype=DTYPE).flatten()
    
    if index + len(flat_vals) > BUFFER_SIZE:
        if index > 0:
            buffer[:index].tofile(OUTPUT_FILE_PATTERN.format(file_count))
            file_count += 1
            print(f"Saved part {file_count-1}") 
        index = 0

    if len(flat_vals) >= BUFFER_SIZE:
        
         flat_vals.tofile(OUTPUT_FILE_PATTERN.format(file_count))
         file_count += 1
         print(f"Directly saved large tensor to part {file_count-1}")
    else:
        buffer[index:index+len(flat_vals)] = flat_vals
        index += len(flat_vals)
        if index >= BUFFER_SIZE:
            buffer.tofile(OUTPUT_FILE_PATTERN.format(file_count))
            file_count += 1
            print(f"Saved part {file_count-1}")
            index = 0
