import torch
from typing import Tuple
import torch.distributed as dist
from crypten import communicator as comm
from .provider.teep_provider import teep_request
from .TESCOrand import random_int_tensor
from  crypten.mpc.primitives.arithmetic import ArithmeticSharedTensor


def pack_bits(bits: torch.Tensor) -> Tuple[torch.Tensor, int]:
 
    bits = bits.to(torch.uint8).flatten()
    orig_len = bits.numel()
    padding = (8 - orig_len % 8) % 8
    if padding > 0:
        bits = torch.cat([
            bits,
            torch.zeros(padding, dtype=bits.dtype, device=bits.device)
        ], dim=0)
    bits = bits.view(-1, 8)
    weights = 2 ** torch.arange(7, -1, -1, dtype=bits.dtype, device=bits.device)
    packed = (bits * weights).sum(dim=1).to(torch.uint8)
    return packed, orig_len

def unpack_bits(packed: torch.Tensor, orig_len: int) -> torch.Tensor:

    packed = packed.to(torch.uint8).flatten()
    
    shifts = torch.arange(7, -1, -1, device=packed.device)
    bits = ((packed.unsqueeze(1).bitwise_right_shift(shifts) & 1)
            .to(torch.uint8))
    bits = bits.view(-1)
    if bits.numel() > orig_len:
        bits = bits[:orig_len]
    return bits

def pack_tensor64(x: torch.Tensor, i: int) -> Tuple[torch.Tensor, int, torch.Size]:

    bits = torch.bitwise_and(torch.bitwise_right_shift(x, i), 1).to(torch.uint8)
    packed, orig_len = pack_bits(bits)
    return packed, orig_len, x.shape

def unpack_tensor64(packed: torch.Tensor,
                    orig_len: int,
                    shape: torch.Size) -> torch.Tensor:
    
    bits = unpack_bits(packed, orig_len)
    return bits.view(shape)

from crypten.TESCO3time import *

def TESCO3teemulbit1(shx,shy):
        sendrank=0;
        if cfg.r3fourth==1:
            sendrank=3
        #print('p1s',i)
        with r3namedtime('p1 msb gen rand'):
            v=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed01).to(shx.device)
            tx1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
            ty1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
            tu1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        with r3namedtime('p1 msb cal dxdy'):
            dx1=shx^tx1;dy1=shy^ty1;
            w1=dist.isend(dx1.cpu(),sendrank);waitlist.append(w1)
            w2=dist.isend(dy1.cpu(),sendrank);waitlist.append(w2)
        with r3namedtime('p1 msb cal z1'):
            z1=(dx1.to(shy.device)&shy)^ (shx&dy1.to(shy.device))^tu1.to(shy.device)^v.to(shy.device)
        #w1.wait();w2.wait();
        #print('p1e',i)
        return z1;
def TESCO3teemulbit0(shx,shy):
    recvrank=1;
    if cfg.r3fourth==1:
        recvrank=3
    with r3namedtime('p0 msb gen rand'):
        v=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed01)
    w1=dist.isend(shx.cpu(),2)
    w2=dist.isend(shy.cpu(),2)
    from crypten import r3fourthrecords

    with r3namedtime('p0 msb recv dx1dy1u0'):
        u0=torch.zeros_like(shx,device='cpu');dx1=torch.zeros_like(shx,device='cpu');dy1=torch.zeros_like(shx,device='cpu')
        dist.recv(dx1,recvrank)
        dist.recv(dy1,recvrank)
        if cfg.r3fourthrecording==1:
            r3fourthrecords.append([dx1.shape,dx1.dtype])
            r3fourthrecords.append([dy1.shape,dy1.dtype])

    with r3namedtime('p0 wait tee'):
        w1.wait();w2.wait();
        dist.recv(u0,2)
    with r3namedtime('p0 cal z0'):
        z0=(dx1.to(shy.device)&shy)^ (shx&dy1.to(shy.device))^u0.to(shy.device)^v.to(shy.device)
    
    #print('p0e',i)
    return z0;

        
def TESCO3ltz(x):
    
    if hasattr(x, "tensor"):
        x = x.tensor()
    sendrank=0;
    if cfg.r3fourth==1:
        sendrank=3
    recvrank=1;
    if cfg.r3fourth==1:
        recvrank=3

    shift = torch.iinfo(torch.long).bits - 1
    if comm.get().get_rank()==1:
        
        device=x.device
        
        c, orig_len, shape = pack_tensor64(x, i=0)
        c*=0
        zero=torch.zeros_like(c)
        with r3namedtime('p1 msb',0):
            
            if cfg.TESCO3supermsb==0:
                for i in range(shift-1):
                    packed, orig_len, shape = pack_tensor64(x, i=i)
                    shxiyi=TESCO3teemulbit1(packed,zero);
                    shcixiaddyi=TESCO3teemulbit1(packed,c);
                    c=shxiyi^shcixiaddyi
            else:
                for i in range(shift-1):
                    packed, orig_len, shape = pack_tensor64(x, i=i)
                    shxiyi=TESCO3teemulbit1(packed^c,zero);
                    c=shxiyi^c

            packed, orig_len, shape = pack_tensor64(x, i=i)
            c=c^packed
        with r3namedtime('p1 ba2a',0):
            a1=torch.ones_like(x);b1=unpack_tensor64(c, orig_len, shape);
            ta1=random_int_tensor(a1.shape,a1.dtype,comm.get().gseed1).to(device)
            tb1=random_int_tensor(b1.shape,b1.dtype,comm.get().gseed1).to(device)
            u1=random_int_tensor(a1.shape,a1.dtype,comm.get().gseed1).to(device)
            v=random_int_tensor(a1.shape,a1.dtype,comm.get().gseed01).to(device)
            dtab=(b1-tb1)&1;dtaa=a1-ta1;
            senda=((-1)**b1)*dtaa
            waitlist.append( dist.isend(dtab.cpu(),sendrank))
            waitlist.append(dist.isend(senda.cpu(),sendrank))
            z1=b1*dtaa+dtab*ta1+(-1)**dtab*u1-v
        '''
        
        w1=dist.isend(c.cpu(),0)
        otherc=torch.zeros_like(c,device='cpu')
        dist.recv(otherc,0)
        shmsbxor= unpack_tensor64(c^otherc.to(c.device), orig_len, shape)
        w1.wait()'''
        #print('p1 ans',shmsbxor)
        #print('r3ltz return',z1.shape)
        return z1
    if  comm.get().get_rank()==0:
        device=x.device
        c, orig_len, shape = pack_tensor64(x, i=0)
        c*=0
        zero=torch.zeros_like(c)
        teep_request("teeTESCO3ltz",x.device,c.numel(),x.shape)
        with r3namedtime('p0 msb',0):
            if cfg.TESCO3supermsb==0:
                for i in range(shift-1):
                    packed, orig_len, shape = pack_tensor64(x, i=i)
                    shxiyi=TESCO3teemulbit0(zero,packed);
                    shcixiaddyi=TESCO3teemulbit0(packed,c);
                    c=shxiyi^shcixiaddyi
            else:
                for i in range(shift-1):
                    packed, orig_len, shape = pack_tensor64(x, i=i)
                    shxiyi=TESCO3teemulbit0(zero,packed^c);
                    c=shxiyi^c

            packed, orig_len, shape = pack_tensor64(x, i=i)
            c=c^packed

        with r3namedtime('p0 ba2a',0):
            a0=torch.zeros_like(x);b0=unpack_tensor64(c, orig_len, shape);
            dtab=torch.zeros_like(b0,device='cpu');u0=torch.zeros_like(a0,device='cpu')
            neg1b1dtaa=torch.zeros_like(a0,device='cpu')
            dist.send(b0.cpu(),2);dist.send(a0.cpu(),2)

            dist.recv(dtab,recvrank);dist.recv(neg1b1dtaa,recvrank);
            from crypten import r3fourthrecords
            if cfg.r3fourthrecording==1:
                r3fourthrecords.append([dtab.shape,dtab.dtype])
                r3fourthrecords.append([neg1b1dtaa.shape,neg1b1dtaa.dtype])

            dist.recv(u0,2)
            dtab=dtab.to(device);neg1b1dtaa=neg1b1dtaa.to(device);u0=u0.to(device);
            v=random_int_tensor(a0.shape,a0.dtype,comm.get().gseed01).to(device)
            z0=b0*neg1b1dtaa+dtab*a0+((-1)**dtab)*u0+v
        '''
        w1= dist.isend(c.cpu(),1)
        otherc=torch.zeros_like(c,device='cpu')
        dist.recv(otherc,1)
        shmsbxor= unpack_tensor64(c^otherc.to(c.device), orig_len, shape)
        w1.wait()'''
        #print('p0 ans',shmsbxor.dtype)
        #print('r3ltz return',z0.shape)
        return z0

waitlist=[]
def TESCO3waitall1():
    global waitlist
    for i in waitlist:
        i.wait()
    waitlist=[]

def TESCO3teemuladditive1(shx,shy):
        v=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed01).to(shx.device)
        #print('p1 gen v',v,v.dtype)
        tx1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        ty1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        tu1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        dx1=shx+tx1;dy1=shy+ty1;
        
        waitlist.append( dist.isend(dx1.cpu(),0))
        waitlist.append( dist.isend(dy1.cpu(),0))
        
        z1=(dx1*shy)+ (shx*dy1)+tu1-v
        return z1;

def TESCO3teemuladditive0(shx,shy):
        v=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed01).to(shx.device)
        #print('p0 gen v',v,v.dtype)
        
        dist.send(shx.cpu(),2);
        dist.send(shy.cpu(),2)
        u0=torch.zeros_like(shx,device='cpu');dx1=torch.zeros_like(shx,device='cpu');dy1=torch.zeros_like(shx,device='cpu')
        
        dist.recv(u0,2)
        
        dist.recv(dx1,1)
        dist.recv(dy1,1)
        
        z0=(dx1.to(shx.device)*shy)+ (shx*dy1.to(shx.device))+u0.to(shx.device)+v
        
        return z0;

def TESCO3mul(x,w):
    x=x.share;w=w.share
    if hasattr(x, "tensor"):
        x = x.tensor()
    if hasattr(w, "tensor"):
        w = w.tensor()
    shift = torch.iinfo(torch.long).bits - 1
    
    if comm.get().get_rank()==1:
        #print('p1running')
        #tsend=torch.randn(3);dist.send(tsend,0);print('tsend',tsend)
        
        return TESCO3teemuladditive1(x,w)
    if  comm.get().get_rank()==0:
        
        
        teep_request("teeTESCO3mul",x.device,x.shape)
        #tsend=torch.ones(3);dist.recv(tsend,1);print('p0gettsend',tsend)
        
        return TESCO3teemuladditive0(x,w)


def TESCO3teetripleadditive1(shx,shy,op,*args, **kwargs):
    with r3namedtime('p1 generate tx1 ty1'):
        tx1=random_int_tensor(shx.shape,shx.dtype,comm.get().gseed1).to(shx.device)
        ty1=random_int_tensor(shy.shape,shy.dtype,comm.get().gseed1).to(shy.device)
    
    dx1=shx+tx1;dy1=shy+ty1;
    if cfg.r3fourth==0:
        waitlist.append( dist.isend(dx1.contiguous().cpu(),0))
        waitlist.append( dist.isend(dy1.contiguous().cpu(),0))
    else:
        #print('p1send',dx1.shape)
        #print('p1send',dy1.shape)
        waitlist.append( dist.isend(dx1.contiguous().cpu(),3))
        waitlist.append( dist.isend(dy1.contiguous().cpu(),3))
    with r3namedtime('p1 triple mul'):
        z1=getattr(torch, op)(dx1,shy,*args, **kwargs)+ getattr(torch, op)(shx,dy1,*args, **kwargs)

    with r3namedtime('p1 generate v tu1'): 
        v=random_int_tensor(z1.shape,z1.dtype,comm.get().gseed01).to(z1.device)
            #print('p1 gen v',v,v.dtype)
        tu1=random_int_tensor(z1.shape,z1.dtype,comm.get().gseed1).to(z1.device)
    
    z1=z1+tu1-v
    #print('p1finish')
    return z1;
from crypten.config import cfg
def TESCO3teetripleadditive0(shx,shy,op,*args, **kwargs):
        #input()
        from crypten import r3fourthrecords
        with r3namedtime('p0 contiguous'):
            shx=shx.contiguous();shy=shy.contiguous()
        
        
        if cfg.r3fourth==0:
            dx1=torch.empty_like(shx,device='cpu');dy1=torch.empty_like(shy,device='cpu')
            hrdx1=dist.irecv(dx1.data,1);    hrdy1=dist.irecv(dy1.data,1)
        else:
            dx1=torch.empty_like(shx,device='cpu');dy1=torch.empty_like(shy,device='cpu')
            hrdx1=dist.irecv(dx1.data,3);    hrdy1=dist.irecv(dy1.data,3)

        if cfg.r3fourthrecording==1:
            r3fourthrecords.append([dx1.shape,dx1.dtype])
            r3fourthrecords.append([dy1.shape,dy1.dtype])
        
        virtualx=torch.empty_like(shx.data,device='meta');virtualy=torch.empty_like(shy.data,device='meta');
        virtualz=getattr(torch, op)(virtualx,virtualy,*args, **kwargs)
        with r3namedtime('p0 send x,y'):
            with r3namedtime('p0 send x,y tocpu'):
                sshx=shx.cpu();sshy=shy.cpu()
            with r3namedtime('p0 send x,y send'):
                dist.send(sshx,2);
                dist.send(sshy,2)
        
        
        
        with r3namedtime('p0 gen v'):
            v=random_int_tensor(virtualz.shape,virtualz.dtype,comm.get().gseed01).to(shx.device)
        from crypten import r3fourth_queue
        with r3namedtime('p0 recv dx,dy'):
            if cfg.r3fourth==0:
                hrdx1.wait();hrdy1.wait()
            else:
                #print('getting s')
                hrdx1.wait();#dx1=r3fourth_queue.get()
                #print('getting m')
                hrdy1.wait()#dy1=r3fourth_queue.get()
                #print('getting e')
            #dx1=shx.clone().cpu();dy1=shy.clone().cpu()
            #dx1=torch.empty_like(shx,device='cpu');dy1=torch.empty_like(shy,device='cpu')
            #dist.recv(dx1.data,1);    dist.recv(dy1.data,1)
        with r3namedtime('p0 recv u0'):
            u0=torch.empty(virtualz.shape,device='cpu',dtype=shx.dtype)
            hru0=dist.irecv(u0.data,2)
        with r3namedtime('p0 triple mul'):
            z0=getattr(torch, op)(dx1.to(shx.device),shy,*args, **kwargs)   + getattr(torch, op)(shx,dy1.to(shx.device),*args, **kwargs)

        
        with r3namedtime('p0 recv u0'):
            hru0.wait();
        z0=z0+u0.to(z0.device)+v
        
        return z0;

def TESCO3triple(x,y,op,*args, **kwargs):
    #print('TESCO3triple args',args,kwargs)
    x=x.share;y=y.share
    
    '''if hasattr(x, "tensor"):
        x = x.tensor()
    if hasattr(w, "tensor"):
        w = w.tensor()'''
    
    if comm.get().get_rank()==1:
        #print('p1running')
        #tsend=torch.randn(3);dist.send(tsend,0);print('tsend',tsend)
        
        ans=TESCO3teetripleadditive1(x,y,op,*args, **kwargs)
    if  comm.get().get_rank()==0:
        
        
        teep_request("teeTESCO3triple",x.device,x.shape,y.shape,op,*args, **kwargs)
        
        ans= TESCO3teetripleadditive0(x,y,op,*args, **kwargs)
        #v=random_int_tensor(x.shape,x.dtype,comm.get().gseed01).to(x.device)
    return ans




        




def TESCO3softmul1(x1,y1,dx1,dy1):
        v=random_int_tensor(x1.shape,x1.dtype,comm.get().gseed01).to(x1.device)
        
        tu1=random_int_tensor(x1.shape,x1.dtype,comm.get().gseed1).to(x1.device)
        
        
        
        z1=(dx1*y1)+ (x1*dy1)+tu1-v
        return z1;

def TESCO3softmul0(x0,y0,dx1,dy1):
        #teep_request("teeTESCO3softmul",x0.device,x0.shape)
        sp=x0*y0
        teep_request("teeTESCO3triple",x0.device,x0.shape,y0.shape,'mul')
        v=random_int_tensor(x0.shape,x0.dtype,comm.get().gseed01).to(x0.device)
       
        dist.send(x0.cpu(),2);
        dist.send(y0.cpu(),2)

        u0=torch.zeros_like(sp,device='cpu');
        
        dist.recv(u0,2)
        
        z0=(dx1.to(x0.device)*y0)+ (x0*dy1.to(x0.device))+u0.to(x0.device)+v
        
        return z0;



def TESCO3softmax1(x1,y1,dim,num_iter):
    x1.mul_(128);y1.mul_(128)
    dx1=random_int_tensor(x1.shape,x1.dtype,comm.get().gseed1).to(x1.device);
    waitlist.append( dist.isend(dx1.cpu(),0))
    dys=[]
    for i in range(num_iter):
        dys.append(random_int_tensor(y1.shape,y1.dtype,comm.get().gseed1).to(y1.device));waitlist.append( dist.isend(dys[-1].cpu(),0))
        a1=TESCO3softmul1(x1,y1,dx1,dys[-1])
        a1.div_(65536*128,rounding_mode="trunc");
        q1=a1.sum(dim=dim).unsqueeze(-1)

        dq1=random_int_tensor(q1.shape,q1.dtype,comm.get().gseed1).to(q1.device);waitlist.append( dist.isend(dq1.cpu(),0))

        s1=TESCO3softmul1(q1,y1,dq1,dys[-1])
        s1.div_(65536*128,rounding_mode="trunc");

        y1+=a1-s1
    return y1.div_(128,rounding_mode="trunc");



def TESCO3softmax0(x0,y0,dim,num_iter):
    dx1=torch.empty_like(x0,device='cpu');dist.recv(dx1,1)
    dy=torch.empty_like(y0,device='cpu');
    x0.mul_(128);y0.mul_(128)
    for i in range(num_iter):
        dist.recv(dy,1)
        a0=TESCO3softmul0(x0,y0,dx1,dy)
        a0.div_(65536*128,rounding_mode="trunc");
        q0=a0.sum(dim=dim).unsqueeze(-1)

        dq1=torch.empty_like(q0,device='cpu');dist.recv(dq1,1)

        s0=TESCO3softmul0(q0,y0,dq1,dy)
        s0.div_(65536*128,rounding_mode="trunc");

        y0+=a0-s0
    return y0.div_(128,rounding_mode="trunc");

def TESCO3softmax(x,y,dim,iter_num,*args, **kwargs):
    x=x.share;y=y.share;
    if hasattr(x, "tensor"):
        x = x.tensor()
    if hasattr(y, "tensor"):
        y = y.tensor()
    if comm.get().get_rank()==1:
        return TESCO3softmax1(x,y,dim,iter_num)
       
    if  comm.get().get_rank()==0:
        return TESCO3softmax0(x,y,dim,iter_num)

def TESCO3sin(x,*args, **kwargs):
    x=x.share;
    if hasattr(x, "tensor"):
        x = x.tensor()
    
    T=256;pie=3.141592653589793238;
    k=2*pie/T
    ik=int(65536/k)
    x=x*ik//65536
    if comm.get().get_rank()==1:
        tx=random_int_tensor(x.shape,x.dtype,comm.get().gseed1).to(x.device)
        
    
        dx1=x+tx;
        if cfg.r3fourth==0:
            waitlist.append( dist.isend(dx1.contiguous().cpu(),0))
        else:
            waitlist.append( dist.isend(dx1.contiguous().cpu(),3))
        
        v=random_int_tensor(x.shape,x.dtype,comm.get().gseed01).to(x.device)
        u=random_int_tensor(x.shape,x.dtype,comm.get().gseed1).to(x.device)
        
        uv=u+v
        fuv=(torch.sin(uv*k/65536.0)*65536).to(x.dtype);guv=(torch.cos(uv*k/65536.0)*65536).to(x.dtype)
        zero=torch.zeros_like(x)
        s2=TESCO3teetripleadditive1(zero,guv,"mul",*args, **kwargs)
        s1= TESCO3teetripleadditive1(fuv,zero,"mul",*args, **kwargs)
        return s1+s2
       
        


    if  comm.get().get_rank()==0:
        teep_request("teeTESCO3sin",x.device,x.shape)
        if cfg.r3fourth==0:
            dx1=torch.empty_like(x,device='cpu');
            hrdx1=dist.irecv(dx1.data,1);    
        else:
            dx1=torch.empty_like(x,device='cpu');
            hrdx1=dist.irecv(dx1.data,3);    
        if cfg.r3fourthrecording==1:
            r3fourthrecords.append([dx1.shape,dx1.dtype])
        
        sx=x.cpu();
        dist.send(sx,2);
        hrdx1.wait()
        u0=torch.empty_like(x,device='cpu'); dist.recv(u0,2)
        xuv=u0.to(x.device)+dx1.to(x.device)
        #print(xuv)
        fxuv=(torch.sin(xuv*k/65536.0)*65536).to(x.dtype);gxuv=(torch.cos(xuv*k/65536.0)*65536).to(x.dtype)
        zero=torch.zeros_like(x,dtype=x.dtype)
        teep_request("teeTESCO3triple",x.device,x.shape,x.shape,op='mul',*args, **kwargs)
        s1= TESCO3teetripleadditive0(fxuv,zero,"mul",*args, **kwargs)
        teep_request("teeTESCO3triple",x.device,x.shape,x.shape,op='mul',*args, **kwargs)
        s2=TESCO3teetripleadditive0(zero,gxuv,"mul",*args, **kwargs)
        return s1+s2


def TESCO3superembeddingoldest(indices,weight):
    indices=indices//65536
    num_token=indices.shape[1]; num_embedding=weight.shape[1]; voc_size=weight.shape[0]
    ans=torch.zeros((num_token,num_embedding),dtype=weight.dtype)
    import os
    if os.environ['RANK']=='0':
        teep_request("teeTESCO3embedding",'cpu',num_token,voc_size,num_embedding)
        dist.send(indices.cpu(),1)
        idsubr1=indices.clone()
        dist.recv(idsubr1,1)
        r2=random_int_tensor(indices.shape,indices.dtype,comm.get().gseed01)
        idsubr1subr2=idsubr1-r2
        #print('P0:','r2',r2)
        for i in range(num_token):

            wr1=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed01);

            waddwr1=torch.roll(weight.cpu()+wr1,shifts=-idsubr1subr2[0][i].item(),dims=0)
            #dist.send(idsubr1subr2.cpu(),2)
            dist.send(waddwr1.cpu(),2)
            wret=waddwr1;dist.recv(wret,2)
            wret=torch.roll(wret,shifts=-r2[0][i].item(),dims=0)
            ans[i]=wret[0]

        

    if os.environ['RANK']=='1':
        #print('ind shape',indices.shape)
        shindice=indices.clone()
        dist.recv(shindice,0)
        indices+=shindice;
        r1=random_int_tensor(indices.shape,indices.dtype,comm.get().gseed1);r2=random_int_tensor(indices.shape,indices.dtype,comm.get().gseed01)
        #print('P1:r1',r1,'r2',r2)
        waitlist.append( dist.isend(((indices-r1)%weight.shape[0]).cpu(),0))
        for i in range(num_token):
             wr1=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed01);wr2=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed1)
             #print('p1wr2',wr2[:,0:10])
             ans[i]=weight[indices[0][i].item()]-wr1[indices[0][i].item()]-wr2[(r2[0][i]%weight.shape[0]).item()]

    return ArithmeticSharedTensor.from_shares(ans)


def TESCO3superembeddingold(indices,weight):
    indices=indices//65536
    num_token=indices.shape[1]; num_embedding=weight.shape[1]; voc_size=weight.shape[0]
    ans=torch.zeros((num_token,num_embedding),dtype=weight.dtype)
    import os
    if os.environ['RANK']=='0':
        teep_request("teeTESCO3embedding",'cpu',num_token,voc_size,num_embedding)
        dist.send(indices.cpu(),1)
        idsubr1=indices.clone()
        dist.recv(idsubr1,1)
        sends=[]
        
        for i in range(num_token):

            R2=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed01);

            dta=torch.roll(weight.cpu()+R2,shifts=-idsubr1[0][i].item(),dims=0)
            #dist.send(idsubr1subr2.cpu(),2)
            sends.append(dist.isend(dta.cpu(),2))
        for i in range(num_token):
            sends[i].wait()
            dist.recv(ans[i],2)
            
            

        

    if os.environ['RANK']=='1':
        #print('ind shape',indices.shape)
        shindice=indices.clone()
        dist.recv(shindice,0)
        indices+=shindice;
        r=random_int_tensor(indices.shape,indices.dtype,comm.get().gseed1);
        #print('P1:r1',r1,'r2',r2)
        waitlist.append( dist.isend(((indices-r)%weight.shape[0]).cpu(),0))
        for i in range(num_token):
             R2=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed01);R1=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed1)
             #print('p1wr2',wr2[:,0:10])
             ans[i]=weight[indices[0][i].item()]-R2[indices[0][i].item()]-R1[0]#R1[(r2[0][i]%weight.shape[0]).item()]

    return ArithmeticSharedTensor.from_shares(ans)

def get_permutation_list(keys: torch.Tensor) -> list:

   
    sorted_indices = torch.argsort(keys)
    
    ranks = torch.argsort(sorted_indices)
    return ranks.tolist()

def TESCO3superembeddingshuffle(indices,weight):
    indices=indices//65536
    num_token=indices.shape[1]; num_embedding=weight.shape[1]; voc_size=weight.shape[0]
    ans=torch.zeros((num_token,num_embedding),dtype=weight.dtype)
    pieid=torch.zeros((num_token),dtype=weight.dtype)
    dtype=torch.long
    import os
    if os.environ['RANK']=='0':
        teep_request("teeTESCO3embedding",'cpu',num_token,voc_size,num_embedding)
        #print('0 embd s')
        dist.send(indices.cpu(),1)
        
        wr1=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed01)*0
        th=dist.isend(weight.cpu()+wr1,2)
        #print('0 embd s0.1')
        dist.recv(pieid,1)
        #print('0 embd s1')
        shpiew=wr1;
        th.wait()
        dist.recv(shpiew,2)
        #print('0 embd s2')
        
        for i in range(num_token):

           ans[i]=shpiew[pieid[i].item()]
           
        

    if os.environ['RANK']=='1':
        #print('ind shape',indices.shape)
        #print('1 embd s')
        shindice=indices.clone()
        dist.recv(shindice,0)
        indices+=shindice;
        #print('1 embd s1')
        pier=random_int_tensor([voc_size],dtype,comm.get().gseed1);print('pier:',pier)
        pie=get_permutation_list(pier)
        for i in range(num_token):
            indices[0][i]=pie[indices[0][i].item()]
        #print('1 embd s2')
        th=dist.isend(indices[0].cpu(),0)
        wr1=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed01)*0
        wr2=random_int_tensor(weight.shape,dtype,comm.get().gseed1)*0
        th.wait()
        #print('1 embd s3')
        for i in range(num_token):
             
             ans[i]=weight[indices[0][i].item()]-wr1[indices[0][i].item()]-wr2[pie[indices[0][i].item()]]

    return ArithmeticSharedTensor.from_shares(ans)
    
def TESCO3superembedding(indices,weight):
    indices=indices//65536
    num_token=indices.shape[1]; num_embedding=weight.shape[1]; voc_size=weight.shape[0]
    
    voc_size=num_token
    weight=torch.ones([num_token,num_embedding],dtype=weight.dtype)
    ans=torch.empty((num_token,num_embedding),dtype=weight.dtype)
    import os
    if os.environ['RANK']=='0':
        teep_request("teeTESCO3embedding",'cpu',num_token,voc_size,num_embedding)
        dist.send(indices.cpu(),1)
        idsubr1=indices.clone()
        dist.recv(idsubr1,1)
        sends=[]
        #dummydta=torch.zeros_like(weight).cpu()
        
        for i in range(num_token):
            R2=random_int_tensor([voc_size,num_embedding],weight.dtype,comm.get().gseed01);
            dta=torch.roll(weight.cpu(),shifts=-idsubr1[0][i].item(),dims=0)+R2
            
            sends.append(dist.isend(dta,2))
            print('p0 roll',i)
        for i in range(num_token):
            print('p0 conclude',i)
            sends[i].wait()
        dist.recv(ans,2)
            
            

        

    if os.environ['RANK']=='1':
        #print('ind shape',indices.shape)
        shindice=indices.clone()
        dist.recv(shindice,0)
        indices+=shindice;
        r=random_int_tensor(indices.shape,indices.dtype,comm.get().gseed1)%voc_size;
        #print('P1:r1',r1,'r2',r2)
        waitlist.append( dist.isend(((indices-r)%weight.shape[0]).cpu(),0))
        for i in range(num_token):
             R2=random_int_tensor(weight.shape,weight.dtype,comm.get().gseed01);
             R1=random_int_tensor([num_embedding],weight.dtype,comm.get().gseed1)
             #print('p1wr2',wr2[:,0:10])
             ans[i]=weight[indices[0][i].item()]-R2[indices[0][i].item()]-R1#R1[(r2[0][i]%weight.shape[0]).item()]

    return ArithmeticSharedTensor.from_shares(ans)