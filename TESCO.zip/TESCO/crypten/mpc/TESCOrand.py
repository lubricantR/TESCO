import torch
import aesrng

emp=torch.empty([1,1])
def random_int_tensor(shape, dtype=torch.long , generator=None,seed=123, offset=0):
    
    info = torch.iinfo(dtype)
    #print('rands',shape,dtype,flush=True)
    ans= torch.ops.aesrng.random_int_tensor(
        torch.empty([1,1]), list(shape), dtype, int(seed), int(offset)
    )
    return torch.empty(shape,dtype=dtype)
    return torch.randint(info.min, info.max, shape, dtype=dtype, generator=generator)
    #print('rande',shape,dtype,flush=True)