import time
global lastcounter
nametimes={}
namerepeats={}
def flushtimer():
    global lastcounter
    lastcounter=time.perf_counter()

def r3time(name):
    global lastcounter
    end = time.perf_counter()
    print(f"{name}:{end - lastcounter:.3E}s")
    lastcounter=end

from contextlib import contextmanager

@contextmanager
def r3namedtime(name="code",valid=1):
    if valid==0:
        yield
    else:
        start = time.perf_counter()
        yield
        end = time.perf_counter()
        #print(f"{name}:{end - start:.3E}s")
        if not name in nametimes:
            nametimes[name]=0.0
            namerepeats[name]=0

        nametimes[name]+=end-start
        namerepeats[name]+=1
@contextmanager
def r3namedtimesum(name="code",valid=1):
    if valid==0:
        yield
    else:
        start = time.perf_counter()
        yield
        end = time.perf_counter()
        #print(f"{name}:{end - start:.3E}s")
        if not name in nametimes:
            nametimes[name]=0.0
            namerepeats[name]=0

        nametimes[name]+=end-start
        namerepeats[name]=1
def r3timeprintall():
    for k in nametimes:
        print(f"{k}:{nametimes[k]/namerepeats[k]:.3E}\t\t\t\tsum{nametimes[k]:.3E}")
    