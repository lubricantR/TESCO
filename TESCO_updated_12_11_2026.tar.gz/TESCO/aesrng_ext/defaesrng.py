import torch
import aesrng  # compiled extension


def random_int_tensor(shape, dtype=torch.int32, generator=None, seed=None, offset=0):
    """
    CPUtensordtype randint(iinfo.min, iinfo.max) 
     [low, high) bitstream
    """
    #if dtype not in (torch.int32, torch.int64):
    #    raise TypeError("dtype must be torch.int32 or torch.int64 (toy version)")

    if seed is None:
        #  generator seed seed
        if generator is not None:
            # generator.initial_seed() generator
            seed = generator.initial_seed()
        else:
            seed = torch.seed()

    #  op
    #  dummy  None
    return aesrng.random_int_tensor(None, shape, dtype, int(seed), int(offset))
    #return torch.ops.aesrng.random_int_tensor(None, list(shape), int(dtype), int(seed), int(offset))
random_int_tensor([100,100])