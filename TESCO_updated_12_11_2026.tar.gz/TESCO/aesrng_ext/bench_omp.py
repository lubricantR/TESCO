import os
import time
from torch.utils.cpp_extension import load
import torch

this_dir = os.path.dirname(os.path.abspath(__file__))

mod = load(
    name="aesrng_omp",
    sources=[os.path.join(this_dir, "aesrng_omp.cpp")],
    extra_cflags=["-O3", "-std=c++17", "-maes", "-msse2", "-march=native", "-fopenmp"],
    extra_ldflags=["-fopenmp"],
    verbose=True,
)

#  OMP 
os.environ["OMP_NUM_THREADS"] = "32"

num_bytes = 8 * 1024 * 1024 * 1024  # 2GB
print("generating", num_bytes / (1024**3), "GB")

# warmup
_ = mod.random_bytes_omp(int(num_bytes),123)

t0 = time.perf_counter()
x = mod.random_bytes_omp(int(num_bytes),123)
t1 = time.perf_counter()

sec = t1 - t0
gbs = num_bytes / sec / (1024**3)
print(f"time: {sec:.3f} s, throughput: {gbs:.2f} GB/s")