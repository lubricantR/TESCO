#include <torch/extension.h>
#include <ATen/Parallel.h>
#include <immintrin.h>
#include <stdint.h>
#include <string.h>

// ---------------- AES-128 key schedule () ----------------
static inline __m128i aes128_keygen_assist(__m128i key, int rcon) {
    __m128i tmp = _mm_aeskeygenassist_si128(key, rcon);
    tmp = _mm_shuffle_epi32(tmp, _MM_SHUFFLE(3,3,3,3));
    __m128i k = key;
    k = _mm_xor_si128(k, _mm_slli_si128(k, 4));
    k = _mm_xor_si128(k, _mm_slli_si128(k, 4));
    k = _mm_xor_si128(k, _mm_slli_si128(k, 4));
    return _mm_xor_si128(k, tmp);
}

struct AES128KeySchedule {
    __m128i rk[11];
};

static inline AES128KeySchedule aes128_expand_key(const uint8_t key16[16]) {
    AES128KeySchedule ks;
    ks.rk[0] = _mm_loadu_si128((const __m128i*)key16);
    ks.rk[1]  = aes128_keygen_assist(ks.rk[0], 0x01);
    ks.rk[2]  = aes128_keygen_assist(ks.rk[1], 0x02);
    ks.rk[3]  = aes128_keygen_assist(ks.rk[2], 0x04);
    ks.rk[4]  = aes128_keygen_assist(ks.rk[3], 0x08);
    ks.rk[5]  = aes128_keygen_assist(ks.rk[4], 0x10);
    ks.rk[6]  = aes128_keygen_assist(ks.rk[5], 0x20);
    ks.rk[7]  = aes128_keygen_assist(ks.rk[6], 0x40);
    ks.rk[8]  = aes128_keygen_assist(ks.rk[7], 0x80);
    ks.rk[9]  = aes128_keygen_assist(ks.rk[8], 0x1B);
    ks.rk[10] = aes128_keygen_assist(ks.rk[9], 0x36);
    return ks;
}

static inline __m128i aes128_encrypt_block(__m128i in, const AES128KeySchedule& ks) {
    __m128i x = _mm_xor_si128(in, ks.rk[0]);
    x = _mm_aesenc_si128(x, ks.rk[1]);
    x = _mm_aesenc_si128(x, ks.rk[2]);
    x = _mm_aesenc_si128(x, ks.rk[3]);
    x = _mm_aesenc_si128(x, ks.rk[4]);
    x = _mm_aesenc_si128(x, ks.rk[5]);
    x = _mm_aesenc_si128(x, ks.rk[6]);
    x = _mm_aesenc_si128(x, ks.rk[7]);
    x = _mm_aesenc_si128(x, ks.rk[8]);
    x = _mm_aesenc_si128(x, ks.rk[9]);
    x = _mm_aesenclast_si128(x, ks.rk[10]);
    return x;
}

// simple seed->key16 (toy)
static inline void seed_to_key16(uint64_t seed, uint8_t key16[16]) {
    auto mix = [](uint64_t x) {
        x += 0x9e3779b97f4a7c15ULL;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
        x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
        x ^= (x >> 31);
        return x;
    };
    uint64_t a = mix(seed);
    uint64_t b = mix(seed ^ 0xD2B74407B1CE6E93ULL);
    memcpy(key16 + 0, &a, 8);
    memcpy(key16 + 8, &b, 8);
}

// ---------------- Modified Core Function ----------------

torch::Tensor random_raw_tensor_aesni(
    torch::IntArrayRef shape,
    c10::ScalarType dtype,
    uint64_t seed,
    uint64_t offset_elements)
{
    // 1.  Tensor
    auto opts = torch::TensorOptions().dtype(dtype).device(torch::kCPU);
    auto out = torch::empty(shape, opts);
    
    //  torch::empty 
    if (!out.is_contiguous()) {
        out = out.contiguous();
    }

    // 2.  ()
    const size_t elem_size = c10::elementSize(dtype);
    const size_t n_elements = (size_t)out.numel();
    const size_t total_bytes = n_elements * elem_size;

    // 3.  Key
    uint8_t key16[16];
    seed_to_key16(seed, key16);
    AES128KeySchedule ks = aes128_expand_key(key16);

    // 4.  ()
    uint8_t* out_bytes = (uint8_t*)out.data_ptr();
    const uint64_t offset_bytes = offset_elements * (uint64_t)elem_size;
    
    //  AES Counter  Block  Block 
    const uint64_t start_block = offset_bytes / 16;
    const uint64_t skip = offset_bytes % 16; //  block 

    //  AES Block 
    //  skip block
    const size_t need_bytes = (size_t)skip + total_bytes;
    const size_t need_blocks = (need_bytes + 15) / 16;

    // -----------------------------------------------------------
    // Fast Path:  16 
    // -----------------------------------------------------------
    if (offset_bytes == 0 && (total_bytes % 16 == 0)) {
        size_t nblocks = total_bytes / 16;

        #pragma omp parallel for schedule(static)
        for (int64_t b = 0; b < (int64_t)nblocks; ++b) {
            uint8_t* dst = out_bytes + (size_t)b * 16;
            //  nonce  counter
            //  nonce counter  block 
            uint64_t nonce = 0xABCDEF0012340000ULL;
            uint64_t ctr_lo = (uint64_t)b; 
            
            __m128i ctr0 = _mm_set_epi64x((long long)nonce, (long long)ctr_lo);
            __m128i enc = aes128_encrypt_block(ctr0, ks);
            _mm_storeu_si128((__m128i*)dst, enc);
        }
        return out;
    }

    // -----------------------------------------------------------
    // Generic Path: 
    //  buffer () 
    // 
    // -----------------------------------------------------------
    
    std::vector<uint8_t> tmp;
    uint8_t* base_ptr = out_bytes;
    bool using_tmp = false;

    // 16 Buffer
    if (skip != 0 || (need_bytes % 16) != 0) {
        tmp.resize(need_blocks * 16);
        base_ptr = tmp.data();
        using_tmp = true;
    }

    const int64_t total_blocks = (int64_t)need_blocks;

    #pragma omp parallel for schedule(static)
    for (int64_t b = 0; b < total_blocks; ++b) {
        //  ( tmp  out_bytes )
        uint8_t* dst = base_ptr + b * 16;

        uint64_t nonce = 0xABCDEF0012340000ULL;
        // 
        uint64_t ctr_lo = start_block + (uint64_t)b;
        
        __m128i ctr0 = _mm_set_epi64x((long long)nonce, (long long)ctr_lo);
        __m128i enc = aes128_encrypt_block(ctr0, ks);
        
        _mm_storeu_si128((__m128i*)dst, enc);
    }

    //  Buffer Tensor 
    if (using_tmp) {
        //  buffer  skip  total_bytes 
        memcpy(out_bytes, base_ptr + skip, total_bytes);
    }

    return out;
}


// wrapper for Torch library
static torch::Tensor random_raw_tensor_dispatch(
    c10::optional<torch::Tensor> /*dummy*/,
    torch::IntArrayRef shape,
    int64_t dtype_int, //  int  dtype
    int64_t seed,
    int64_t offset)
{
    return random_raw_tensor_aesni(
        shape,
        (c10::ScalarType)dtype_int,
        (uint64_t)seed,
        (uint64_t)offset);
}

TORCH_LIBRARY(aesrng, m) {
    // Python  dtype  int ( int(torch.float32))
    m.def("random_int_tensor(Tensor? dummy, int[] shape, int dtype, int seed, int offset) -> Tensor");
    m.impl("random_int_tensor",
           c10::DispatchKey::CPU,
           TORCH_FN(random_raw_tensor_dispatch));
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("dummy", []() { return 0; }, "dummy function");
}