# test_seed_throughput.py
import time
import torch
import aesrng  #  op 


def random_int_tensor(shape, dtype=torch.int32, seed=123, offset=0):
    return torch.ops.aesrng.random_int_tensor(
        torch.empty([1,1]), list(shape), dtype, int(seed), int(offset)
    )


def test_seed_repro():
    print("=== seed reproducibility ===")
    x1 = random_int_tensor((4, 4), dtype=torch.int32, seed=123, offset=0)
    x2 = random_int_tensor((4, 4), dtype=torch.int32, seed=123, offset=0)
    print("same seed, same offset ->", torch.equal(x1, x2))

    x3 = random_int_tensor((4, 4), dtype=torch.int32, seed=124, offset=0)
    print("different seed -> usually not equal ->", not torch.equal(x1, x3))


def test_offset():
    print("\n=== offset behavior ===")
    seed = 777
    full = random_int_tensor((10000,), dtype=torch.int32, seed=seed, offset=0)
    part = random_int_tensor((1024,), dtype=torch.int32, seed=seed, offset=4000)
    ok = torch.equal(full[4000:4000 + 1024], part)
    print("full[4000:4000+1024] == part ?", ok)


def benchmark_throughput(total_mb=2048, dtype=torch.int32, seed=1, iters=5):
    print("\n=== throughput benchmark ===")
    print(f"total: {total_mb} MB, dtype: {dtype}, iters: {iters}")

    elem_size = 4 if dtype == torch.int32 else 8
    total_bytes = total_mb * 1024 * 1024
    num_elems = total_bytes // elem_size
    shape = (num_elems,)

    # warmup
    _ = random_int_tensor(shape, dtype=dtype, seed=seed, offset=0)

    best_gbs = 0.0
    for i in range(iters):
        t0 = time.perf_counter()
        #_ = random_int_tensor(shape, dtype=dtype, seed=seed, offset=i * num_elems)
        _ = random_int_tensor(shape, dtype=dtype, seed=seed, offset=0)
        t1 = time.perf_counter()
        sec = t1 - t0
        gbs = total_bytes / sec / (1024 ** 3)
        best_gbs = max(best_gbs, gbs)
        print(f"iter {i}: {gbs:.3f} GB/s ({sec:.3f} s)")
    print(f"best: {best_gbs:.3f} GB/s")


if __name__ == "__main__":
    test_seed_repro()
    test_offset()
    benchmark_throughput(total_mb=8192, dtype=torch.long, seed=123, iters=15)