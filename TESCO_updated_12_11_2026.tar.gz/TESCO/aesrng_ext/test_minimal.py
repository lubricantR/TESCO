import os
from torch.utils.cpp_extension import load
import torch
import time

this_dir = os.path.dirname(os.path.abspath(__file__))

mod = load(
    name="minimal_ext",
    sources=[os.path.join(this_dir, "minimal.cpp")],
    extra_cflags=["-O3", "-std=c++17"],
    verbose=True,
)

print("loaded module:", mod)
x = torch.randn(3, 3)
y = mod.ident(x)
print("x:", x)
print("y:", y)
print("equal:", torch.equal(x, y))