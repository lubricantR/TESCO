import os
from torch.utils.cpp_extension import load
import torch
import time

this_dir = os.path.dirname(os.path.abspath(__file__))

aesrng = load(
    name="aesrng",
    sources=[os.path.join(this_dir, "aesrng.cpp")],
    extra_cflags=["-O3", "-std=c++17", "-maes", "-msse2", "-march=native"],
    verbose=True,
)

print("loaded module:", aesrng)
dummytensor=torch.empty([1,1])
#  Python 
def random_int_tensor(shape, dtype=torch.int32, seed=123, offset=0):
    return torch.ops.aesrng.random_int_tensor(
        dummytensor, list(shape), dtype, int(seed), int(offset)
    )

print("=== smoke test ===")
x = random_int_tensor((8,), dtype=torch.int32, seed=123, offset=0)
print("x:", x, x.dtype, x.device)

print("\n=== throughput benchmark ===")
total_mb = 2048
elem_size = 4
num_elems = total_mb * 1024 * 1024 // elem_size
shape = (num_elems,)

# warmup
_ = random_int_tensor(shape, dtype=torch.int32, seed=1, offset=0)

best = 0.0
for i in range(5):
    t0 = time.perf_counter()
    _ = random_int_tensor(shape, dtype=torch.int32, seed=1, offset=i * num_elems)
    t1 = time.perf_counter()
    sec = t1 - t0
    gbs = total_mb / sec / 1024
    best = max(best, gbs)
    print(f"iter {i}: {gbs:.3f} GB/s ({sec:.3f} s)")
print("best:", best, "GB/s")