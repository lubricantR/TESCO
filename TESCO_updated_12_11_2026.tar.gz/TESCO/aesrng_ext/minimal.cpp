#include <torch/extension.h>

//  tensor
torch::Tensor ident(torch::Tensor x) {
    return x;
}

//  pybind11  Python
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("ident", &ident, "identity function");
}