from setuptools import setup
from torch.utils.cpp_extension import CppExtension, BuildExtension

extra_compile_args = {
    "cxx": ["-O3", "-std=c++17", "-maes", "-msse2", "-march=native","-fopenmp"],
}

setup(
    name="aesrng",                        # 
    ext_modules=[
        CppExtension(
            name="aesrng",               #  -> PyInit_aesrng
            sources=["aesrng.cpp"],
            extra_compile_args=extra_compile_args,
        )
    ],
    cmdclass={"build_ext": BuildExtension},
)