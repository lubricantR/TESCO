import time
import torch
from defaesrng import random_int_tensor


def test_seed_reproducibility():
    print("=== seed reproducibility test ===")
    shape = (1024, 1024)
    seed = 12345
    offset = 0

    x1 = random_int_tensor(shape, dtype=torch.int32, seed=seed, offset=offset)
    x2 = random_int_tensor(shape, dtype=torch.int32, seed=seed, offset=offset)

    print("same seed, same offset -> equal:", torch.equal(x1, x2))

    x3 = random_int_tensor(shape, dtype=torch.int32, seed=seed + 1, offset=offset)
    print("different seed -> usually not equal:", not torch.equal(x1, x3))


def test_offset_behavior():
    print("\n=== offset behavior test ===")
    shape = (1024,)
    seed = 777

    # 
    full = random_int_tensor((10000,), dtype=torch.int32, seed=seed, offset=0)
    #  offset=4000 
    part = random_int_tensor(shape, dtype=torch.int32, seed=seed, offset=4000)

    eq = torch.equal(full[4000:4000 + shape[0]], part)
    print("full[4000:4000+N] == part ?", eq)


def benchmark_throughput(total_mb=2048, dtype=torch.int32, seed=1, iters=5):
    """
     CPU GB/s
    total_mb: MB
    """
    print("\n=== throughput benchmark ===")
    print(f"total: {total_mb} MB, dtype: {dtype}, iters: {iters}")

    elem_size = 4 if dtype == torch.int32 else 8
    total_bytes = total_mb * 1024 * 1024
    num_elems = total_bytes // elem_size
    shape = (num_elems,)

    # 
    _ = random_int_tensor(shape, dtype=dtype, seed=seed, offset=0)

    best_gbs = 0.0
    for i in range(iters):
        t0 = time.perf_counter()
        #  offset  seed+offset 
        _ = random_int_tensor(shape, dtype=dtype, seed=seed, offset=i * num_elems)
        t1 = time.perf_counter()
        sec = t1 - t0
        gbs = total_bytes / sec / (1024 ** 3)
        best_gbs = max(best_gbs, gbs)
        print(f"iter {i}: {gbs:.3f} GB/s ({sec:.3f} s)")

    print(f"best: {best_gbs:.3f} GB/s")


if __name__ == "__main__":
    test_seed_reproducibility()
    test_offset_behavior()

    #  total_mb  dtype 
    benchmark_throughput(total_mb=2048, dtype=torch.int32, seed=123, iters=5)
    # benchmark_throughput(total_mb=2048, dtype=torch.int64, seed=123, iters=5)