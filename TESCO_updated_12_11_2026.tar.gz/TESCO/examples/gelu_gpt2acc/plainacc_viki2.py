# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 21:51:28 2025

@author: Administrator
"""

from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch
import math
from datasets import load_dataset
device="cuda"
class CustomGPT2Model(torch.nn.Module):
    def __init__(self, model):
        super(CustomGPT2Model, self).__init__()
        
        self.model = model
        self.transformer = model.transformer  
        self.lm_head = model.lm_head  

        
        self.wte = self.transformer.wte
        self.wpe = self.transformer.wpe

        
        self.ln_f = self.transformer.ln_f
        self.drop = self.transformer.drop
        self.h = self.transformer.h

    def forward(self, input_ids, attention_mask=None):
        
        token_embeds = self.transformer.wte(input_ids)  # [1, seq_len, hidden_dim]
        position_ids = torch.arange(0, input_ids.size(1), dtype=torch.long).unsqueeze(0).to(device)
        position_embeds = self.transformer.wpe(position_ids)  # [1, seq_len, hidden_dim]
        input_embeddings = token_embeds + position_embeds
        
        
        embeddings = self.drop(input_embeddings)

       
        hidden_states = embeddings
        for block in self.h:
            hidden_states = block(hidden_states, attention_mask=attention_mask)[0]

       
        hidden_states = self.ln_f(hidden_states)

        
        logits = self.lm_head(hidden_states)
        import code
        #code.interact(local=locals())
        return logits
def logits_to_loss(logits, labels, attention_mask=None):
    
    
    shift_logits = logits[:, :-1, :].contiguous()  
    shift_labels = labels[:, 1:].contiguous()      
    
    
    if attention_mask is not None:
        shift_attention_mask = attention_mask[:, 1:].contiguous()
        
        shift_labels = shift_labels.masked_fill(shift_attention_mask == 0, -100)
    
   
    loss_fn = torch.nn.CrossEntropyLoss(reduction='mean', ignore_index=-100)
    loss = loss_fn(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
    
    return loss.item()
usecustom=True
def calculate_dataset_perplexity(dataset, model_name='openai-community/gpt2', max_length=64):
    tokenizer = GPT2Tokenizer.from_pretrained(model_name)
    model = GPT2LMHeadModel.from_pretrained(model_name).to(device)
    if usecustom:
        model=CustomGPT2Model(model)
    model.eval()
    
    total_loss = 0.0
    total_tokens = 0
    
    for example in dataset:
        text = example["sentence"].strip()
        if not text:  
            continue
        encodings = tokenizer(text, return_tensors="pt", max_length=max_length, truncation=True)
        input_ids = encodings.input_ids.to(device)
        attention_mask = encodings.attention_mask.to(device)
        
        with torch.no_grad():
            outputs = model(input_ids)
            if usecustom:
                loss=logits_to_loss(outputs, input_ids)
            else:
                loss=logits_to_loss(outputs.logits, input_ids)
            print('loss',loss)

            
            if loss is not None and not math.isnan(loss):  
                total_loss += loss * input_ids.size(1)
                total_tokens += input_ids.size(1)
    
    if total_tokens == 0:
        return float("inf")  
    avg_loss = total_loss / total_tokens

    return avg_loss


import os
os.environ["HF_DATASETS_OFFLINE"] = "1"
#dataset = load_dataset("wikitext", "wikitext-2-v1", split="test")
dataset = load_dataset("ptb_text_only", "penn_treebank", split="test")

try:
    perplexity = calculate_dataset_perplexity(dataset)
    print(f"Average Perplexity on WikiText-2 (max_length=128): {perplexity:.2f}")
except Exception as e:
    print(f"An error occurred: {e}")