#!/bin/bash
# Same as launchTESCO3.sh, but the TEE party (rank 2) runs in another container over ssh.
# Usage: MODEL=openai-community/gpt2 LEN=128 bash tdxlaunchTESCO3.sh
export GLOO_SOCKET_IFNAME=${GLOO_SOCKET_IFNAME:-tdx-tap0}
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export MASTER_ADDR=192.168.100.1
export MASTER_PORT=29500
# the remote TEE side needs no model/data; this only resolves p0/p1's inputs
eval "$(python "$(dirname "$0")/assets.py" resolve-model --model "${MODEL:-openai-community/gpt2}")"

LEN=${LEN:-128}
LIMIT_SPEED=${LIMIT_SPEED:-0}
ARGS="--model_name_or_path $MODEL --len_data $LEN"

if [ "$LIMIT_SPEED" = "1" ] && command -v limitipspeedcalaulatecomm.sh >/dev/null 2>&1; then
    limitipspeedcalaulatecomm.sh ${LIMIT_BW:-400000} 0 -- env \
        OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py $ARGS &
else
    OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py $ARGS &
fi

sshpass -p "${TEE_PASS:-123456}" ssh \
  -o StrictHostKeyChecking=accept-new \
  -p "${TEE_PORT:-10022}" "${TEE_USER:-root}@${TEE_HOST:-127.0.0.1}" \
  "source ~/pytorch-env/bin/activate; MASTER_ADDR=$MASTER_ADDR MASTER_PORT=$MASTER_PORT GLOO_SOCKET_IFNAME=${TEE_IFACE:-enp0s2} python ~/rTESCO/TESCO/launchteep2.py" &

OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp0.py $ARGS

wait
