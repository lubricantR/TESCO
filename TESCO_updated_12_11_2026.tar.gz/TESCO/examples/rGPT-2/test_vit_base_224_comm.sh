#!/bin/bash
# Plaintext/reference run of the same demo (no crypten), useful as a sanity check.
MODEL=${MODEL:-openai-community/gpt2} LEN=${LEN:-128} \
    python run_image_classification_private.py --model_name_or_path "${MODEL:-openai-community/gpt2}" --len_data "${LEN:-128}"
