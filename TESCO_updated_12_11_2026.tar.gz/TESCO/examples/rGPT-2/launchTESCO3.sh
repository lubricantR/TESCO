#!/bin/bash
# ================= GPT-2 private inference (3 parties: p0, p1, TEE p2) =================
# Usage:  MODEL=openai-community/gpt2 LEN=128 bash launchTESCO3.sh
# Env overrides:
#   MODEL          local model dir or HF model id   (default: openai-community/gpt2)
#   LEN            sequence length                  (default: 128)
#   OFFLINE=0|1    force online / offline           (default: decided from local assets)
#   LIMIT_SPEED=0  skip the bandwidth limiter       (default 1)
export GLOO_SOCKET_IFNAME=${GLOO_SOCKET_IFNAME:-tdx-tap0}
# the library no longer hardcodes the rendezvous address: it must come from the environment
export MASTER_ADDR=${MASTER_ADDR:-127.0.0.1}
export MASTER_PORT=${MASTER_PORT:-29500}
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

# ---- asset resolution: use the local copy if present, otherwise download from the Hub ----
eval "$(python "$(dirname "$0")/assets.py" resolve-model --model "${MODEL:-openai-community/gpt2}")"

LEN=${LEN:-128}
LIMIT_SPEED=${LIMIT_SPEED:-0}
ARGS="--model_name_or_path $MODEL --len_data $LEN"

if [ "$LIMIT_SPEED" = "1" ] && command -v limitipspeedcalaulatecomm.sh >/dev/null 2>&1; then
    limitipspeedcalaulatecomm.sh ${LIMIT_BW:-1000000} 0 -- env \
        OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py $ARGS &
else
    OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py $ARGS &
fi

python launchteep2.py &

OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp0.py $ARGS

wait
