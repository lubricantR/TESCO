



import torch


import crypten as ct
from crypten.config import cfg




import transformers


import os
import crypten.communicator as comm
import crypten
from crypten.mpc.TESCOltz import TESCO3mul,TESCO3waitall1
from crypten.mpc import MPCTensor

from transformers import GPT2LMHeadModel, GPT2Tokenizer,GPT2Config

import code
from crypten.mpc.TESCOltz import TESCO3waitall1

from crypten.nn.module import setTESCO3device
import time
from crypten.TESCO3time import *
import atexit

# configuration (overridable by env, e.g. MODEL=/path/to/gpt2 LEN=64 bash launchTESCO3.sh)
MODEL = "openai-community/gpt2"
SEQ_LEN = 128


def parse_args():
    import argparse

    p = argparse.ArgumentParser(description="Private GPT-2 inference (TESCO3, 3 parties)")
    p.add_argument("--model_name_or_path", "--model", dest="model",
                   default=os.environ.get("MODEL", MODEL))
    p.add_argument("--len_data", "--length", dest="len_data", type=int,
                   default=int(os.environ.get("LEN", SEQ_LEN)))
    # accepted for compatibility with the older launch scripts; not used by this demo
    p.add_argument("--max_eval_samples", type=int, default=1)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--comp", action="store_true")
    p.add_argument("--acc", action="store_true")
    a, _unknown = p.parse_known_args()
    return a


def r3timeonexit():
    r3timeprintall()
def main():
    with crypten.no_grad():
        atexit.register(r3timeprintall)

        # ---- asset resolution: local model directory first, Hub (download) as a fallback ----
        import assets
        _model = os.environ.get("MODEL") or MODEL
        _res = assets.resolve_model(_model, default="openai-community/gpt2")
        model_name = _res["model"]
        seq_len = int(os.environ.get("LEN", SEQ_LEN))
        print("[assets] model=%s len=%d offline=%s" % (
            model_name, seq_len, _res["offline"]), flush=True)
        #config = GPT2Config.from_pretrained(model_name)
        tokenizer = GPT2Tokenizer.from_pretrained(model_name)
        model = GPT2LMHeadModel.from_pretrained(model_name, attn_implementation="eager")
        for i in range (len(model.transformer.h)):
            model.transformer.h[i].mlp.act = torch.nn.GELU(approximate="tanh")
        #model = GPT2LMHeadModel(config)
        embedding_layer = model.transformer.wte
        
        #print("rank=",os.environ["RANK"])
        text = "what hello test abs cba abc"
        inputs = tokenizer(text, return_tensors="pt")  

        input_ids = inputs["input_ids"]
        input_ids=torch.ones([1,seq_len],dtype=input_ids.dtype)
        if os.environ["RANK"]=='0':
            with torch.no_grad():
                plainresult=model(input_ids)
        
        if os.environ["RANK"]=='1':
            device = "cuda"
        else:
            device = "cuda"
        setTESCO3device(device)
        ct.init()
        
        
        #model=embedding_layer;
        private_model = ct.nn.from_pytorch(model, input_ids).encrypt().to(device)
        torch.manual_seed(3)
    
        m1=ct.cryptensor(input_ids).to(device); 
        
        for i in range(1):

            #z=private_model(m1)
            if os.environ["RANK"]=='0':
                with r3namedtime('runningtime***'):
                    #z=m1.softmax(1)
                    z=private_model(m1)
            else:
                #z=m1.softmax(1)
                z=private_model(m1)

        
            #print(f'p{os.environ["RANK"]}{i}')

            
        print(os.environ["RANK"],'compute end')
        TESCO3waitall1()
        #print((z.get_plain_text()-torch.nn.functional.relu(om1)).abs().mean())
        plain=z.get_plain_text()
        
        if os.environ["RANK"]=='0':
            print(plain[0, :, :10])
            print(plainresult.logits[0, :, :10])
            print('max diff:',(plain.cpu()-plainresult.logits.cpu()).abs().mean())

if __name__ == "__main__":
    
    args = parse_args()
    os.environ.setdefault("MODEL", args.model)
    os.environ.setdefault("LEN", str(args.len_data))

    if args.comp:
        # run without communication
        with cfg.temp_override({"cost.estimate_cost": True, "cost.estimate_mode": "comp"}):
            main()
    else:
        # run with communication
        launcher = MultiProcessLauncher(2, main)
        launcher.start()
        launcher.join()
        launcher.terminate()
