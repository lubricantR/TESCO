



import torch


import crypten as ct
from crypten.config import cfg




import transformers


import os
import crypten.communicator as comm

from crypten.mpc.TESCOltz import TESCO3mul,TESCO3waitall1
from crypten.mpc import MPCTensor

from transformers import GPT2LMHeadModel, GPT2Tokenizer,GPT2Config

import code
from crypten.mpc.TESCOltz import TESCO3waitall1

from crypten.nn.module import setTESCO3device
import time
from crypten.TESCO3time import *
import atexit
def r3timeonexit():
    r3timeprintall()
def main():
    atexit.register(r3timeprintall)
    
    model_name = "openai-community/gpt2"
    #config = GPT2Config.from_pretrained(model_name)
    tokenizer = GPT2Tokenizer.from_pretrained(model_name)
    model = GPT2LMHeadModel.from_pretrained(model_name)
    for i in range (len(model.transformer.h)):
        model.transformer.h[i].mlp.act = torch.nn.GELU(approximate="tanh")
    #model = GPT2LMHeadModel(config)
    embedding_layer = model.transformer.wte
    
    #print("rank=",os.environ["RANK"])
    text = "what hello fuck test abs cba abc"
    inputs = tokenizer(text, return_tensors="pt")  

    input_ids = inputs["input_ids"]
    input_ids=torch.ones([1,128],dtype=input_ids.dtype)
    if os.environ["RANK"]=='0':
        with torch.no_grad():
            plainresult=model(input_ids)
    
    if os.environ["RANK"]=='1':
        device = "cuda"
    else:
        device = "cuda"
    setTESCO3device(device)
    ct.init()
    
    
    #model=embedding_layer;
    private_model = ct.nn.from_pytorch(model, input_ids).encrypt().to(device)
    torch.manual_seed(3)
   
    m1=ct.cryptensor(input_ids).to(device); 
    
    for i in range(1):

        #z=private_model(m1)
        if os.environ["RANK"]=='0':
            with r3namedtime('runningtime***'):
                #z=m1.softmax(1)
                z=private_model(m1)
        else:
            #z=m1.softmax(1)
            z=private_model(m1)

       
        #print(f'p{os.environ["RANK"]}{i}')

        
    print(os.environ["RANK"],'compute end')
    TESCO3waitall1()
    #print((z.get_plain_text()-torch.nn.functional.relu(om1)).abs().mean())
    plain=z.get_plain_text()
    
    if os.environ["RANK"]=='0':
        print(plain[0, :, :10])
        print(plainresult.logits[0, :, :10])
        print('max diff:',(plain.cpu()-plainresult.logits.cpu()).abs().mean())

if __name__ == "__main__":
    
    args = parse_args()
    
    if args.comp:
        # run without communication
        with cfg.temp_override({"cost.estimate_cost": True, "cost.estimate_mode": "comp"}):
            main()
    else:
        # run with communication
        launcher = MultiProcessLauncher(2, main)
        launcher.start()
        launcher.join()
        launcher.terminate()
