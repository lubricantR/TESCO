export TASK_NAME=qnli
 export GLOO_SOCKET_IFNAME=tdx-tap0
 export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
 export TRANSFORMERS_OFFLINE=1
   export HF_HUB_OFFLINE=1
limitipspeed.sh 10000000 0 -- env OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py --model_name_or_path andeskyl/bert-base-cased-$TASK_NAME --task_name $TASK_NAME --len_data 128   --max_length 64 --per_device_eval_batch_size 1 --output_dir eval_private/$TASK_NAME/1 &
#python launchp1.py --model_type=gpt2 --model_name_or_path=openai-community/gpt2 --len_data 64 --length 1 &

python launchteep2.py &
python launchp0.py --model_name_or_path andeskyl/bert-base-cased-$TASK_NAME --task_name $TASK_NAME --len_data 64   --max_length 128 --per_device_eval_batch_size 1 --output_dir eval_private/$TASK_NAME/1 
wait