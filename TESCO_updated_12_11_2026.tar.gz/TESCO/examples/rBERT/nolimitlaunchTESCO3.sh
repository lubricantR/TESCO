#!/bin/bash
# Same as launchTESCO3.sh but without the bandwidth limiter (higher throughput).
# Usage: TASK_NAME=qnli LEN=128 bash nolimitlaunchTESCO3.sh
LIMIT_SPEED=0 exec bash "$(dirname "$0")/launchTESCO3.sh" "$@"
