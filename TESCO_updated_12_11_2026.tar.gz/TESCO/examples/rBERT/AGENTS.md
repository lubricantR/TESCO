当前目录是TESCO项目，这是一个基于Crypten、秘密分享（secret sharing）实现隐私保护的模型推理的库。
TESCO在两方的基础上加入一个TEE辅助方，制订了新的三方乘法、非线性协议，加速推理过程执行
Crypten的核心原理是，基于torch的基本tensor操作，用64位定点数构建秘密分享的share的tensor计算，然后构建module（module.py），给定一个pytorch模型，转化成ONNX，再把其中的节点用自定义的share module替换。
启动实验：./launchTESCO3.sh
