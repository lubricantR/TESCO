#!/bin/bash
# ================= BERT private inference (3 parties: p0, p1, TEE p2) =================
# Usage:
#   TASK_NAME=qnli LEN=128 bash launchTESCO3.sh
# Env overrides:
#   TASK_NAME      qnli / sst2 / ...           (default qnli)
#   LEN            input length                (default 128)
#   MODEL          local dir or HF model id    (default: auto-resolved)
#   DATASET_DIR    local save_to_disk dir      (default: auto-resolved)
#   OFFLINE=0|1    force online / offline      (default: decided from local assets)
#   LIMIT_SPEED=0  skip the bandwidth limiter  (default 1 = limited)
export TASK_NAME=${TASK_NAME:-qnli}
export GLOO_SOCKET_IFNAME=${GLOO_SOCKET_IFNAME:-tdx-tap0}
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export MASTER_ADDR=127.0.0.1
export MASTER_PORT=29500
# ---- asset resolution: use what is on this machine, fetch from the Hub only if missing ----
eval "$(python "$(dirname "$0")/assets.py" resolve --task "$TASK_NAME")"

LEN=${LEN:-128}
LIMIT_SPEED=${LIMIT_SPEED:-0}

# the dataset directory is optional: only pass it if a local one was resolved
EXTRA_ARGS=""
[ -n "$DATASET_DIR" ] && EXTRA_ARGS="--dataset_dir $DATASET_DIR"
ARGS="--model_name_or_path $MODEL --task_name $TASK_NAME --len_data $LEN --max_length $LEN --pad_to_max_length --per_device_eval_batch_size ${BATCH:-1} $EXTRA_ARGS --output_dir ${OUTPUT_DIR:-eval_private/$TASK_NAME/1}"

P1="OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py $ARGS"
if [ "$LIMIT_SPEED" = "1" ] && command -v limitipspeedcalaulatecomm.sh >/dev/null 2>&1; then
    limitipspeedcalaulatecomm.sh ${LIMIT_BW:-10000000} 0 -- env $P1 &
else
    ( OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py $ARGS ) &
fi

python launchteep2.py &

OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp0.py $ARGS

wait
