"""Locating (and, if needed, fetching) the model and dataset for private inference.

Design rule: **always prefer what is already on this machine** (project directories,
HuggingFace local cache) and only go to the HuggingFace Hub when nothing is found.
A downloaded dataset is saved to <this dir>/data/<task>, so later runs are fully offline.

Python usage:
    from assets import resolve, load_dataset
    res = resolve(task="sst2")            # -> dict(model=..., dataset_dir=..., offline=...)
    raw = load_dataset("qnli", res["dataset_dir"])

Shell usage (called by launch_qnli.sh / launch_sst2.sh):
    eval "$(python assets.py resolve)"                # default task = sst2
    # prints:
    #   export MODEL='/path/to/bert-qnli'
    #   export DATASET_DIR='/path/to/data/qnli'
    #   export TRANSFORMERS_OFFLINE=1
    #   export HF_HUB_OFFLINE=1
Environment overrides:
    MODEL / DATASET_DIR   explicit choice (existence is checked below)
    OFFLINE=0|1           force online / force offline; otherwise decided automatically
                          from whether all resources resolve locally
"""

import os
import shutil
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# default task of this directory: SST-2 (model: ./bert-sst2, dataset: ./sst2_hf)
DEFAULT_TASK = os.environ.get("DEFAULT_TASK", "sst2")

# task -> candidate local model directory names, in priority order
LOCAL_MODEL_DIRS = {
    "qnli": ["bert-qnli", "bert-qnli-cased", "bertqnli"],
    "sst2": ["bert-sst2", "bert-sst2-cased", "bertsst2"],
}
# task -> default HuggingFace model id used when no local model exists
HUB_MODEL_FALLBACK = {
    "qnli": "andeskyl/bert-base-cased-qnli",
    "sst2": "andeskyl/bert-base-cased-sst2",
}
# HF dataset repo; the GLUE subset name is simply the task name (qnli/sst2/...)
GLUE_HUB_REPO = "nyu-mll/glue"
GLUE_TASKS = {"cola", "mnli", "mrpc", "qnli", "qqp", "rte", "sst2", "stsb", "wnli"}

# never fetch the non-PyTorch duplicates that big repos also ship (tf / flax / onnx / tflite)
IGNORE_PATTERNS = [
    "*.tflite", "*.onnx", "*.msgpack", "*.h5", "*.ot", "*.ckpt", "*.pth",
    "*.pdparams", "*.mlmodel", "*.tflite.*", "*.onnx_data",
    "onnx/*", "coreml/*", "saved_model/*", "openvino/*", "ggml*", "*.gguf",
]


def download_model(repo):
    """Fetch only what a PyTorch model needs: config/tokenizer + exactly ONE weights file.

    Big repositories ship the same weights in many formats (gpt2 has ~4.5 GB of TF / Flax /
    ONNX / TFLite copies plus a pytorch_model.bin). Only safetensors is fetched when the repo
    provides it, otherwise pytorch_model.bin; everything else is skipped.
    """
    from huggingface_hub import snapshot_download

    meta = ["*.json", "*.txt", "*.model", "tokenizer*", "vocab*", "merges*"]
    files = []
    try:
        from huggingface_hub import HfApi

        files = HfApi().list_repo_files(repo)
    except Exception:
        pass                                    # cannot list -> assume safetensors, retry below
    if files:
        weights = (["*.safetensors", "*.safetensors.index.json"]
                   if any(f.endswith(".safetensors") for f in files)
                   else ["*.bin", "*.bin.index.json"])
    else:
        weights = ["*.safetensors", "*.safetensors.index.json"]
    try:
        return snapshot_download(repo, allow_patterns=meta + weights, ignore_patterns=IGNORE_PATTERNS)
    except Exception:
        if not files:                           # listing failed: this repo may only ship *.bin
            return snapshot_download(repo, allow_patterns=meta + ["*.bin", "*.bin.index.json"],
                                     ignore_patterns=IGNORE_PATTERNS)
        raise



_SAY_STREAM = sys.stdout


def _say(*a):
    print("[assets]", *a, file=_SAY_STREAM, flush=True)


def is_model_dir(path):
    return bool(path) and os.path.isdir(path) and os.path.isfile(os.path.join(path, "config.json"))


def is_dataset_dir(path):
    """A directory written by datasets.save_to_disk (contains dataset_dict.json)."""
    return bool(path) and os.path.isdir(path) and os.path.isfile(
        os.path.join(path, "dataset_dict.json")
    )


def hub_id_cached(model_id):
    """True if this hub id already has a snapshot with config.json in the local HF cache."""
    if not model_id or "/" not in model_id or os.path.isdir(model_id):
        return False
    for home in dict.fromkeys((os.path.expanduser("~"), os.path.expanduser("~root"))):
        snap = os.path.join(home, ".cache/huggingface/hub",
                            "models--" + model_id.replace("/", "--"), "snapshots")
        if os.path.isdir(snap):
            for rev in os.listdir(snap):
                if os.path.isfile(os.path.join(snap, rev, "config.json")):
                    return True
    return False


def dataset_candidates(task, dataset_dir=None, root=None):
    """Candidate local directories for this task's dataset, in priority order."""
    root = root or SCRIPT_DIR
    home = os.path.expanduser("~")
    cands = []
    if dataset_dir:
        cands.append(dataset_dir)
    cands += [
        os.path.join(root, "%s_hf" % task),
        os.path.join(root, "data", task),
        os.path.join(home, ".cache/huggingface/hub/datasets", "bert%s" % task),
        os.path.join(os.path.expanduser("~"), ".cache/huggingface/hub/datasets/bert%s" % task),
    ]
    return cands


def model_candidates(task, root=None):
    root = root or SCRIPT_DIR
    return [os.path.join(root, n) for n in LOCAL_MODEL_DIRS.get(task, [])]


def find_local_model(task, model=None, root=None):
    if is_model_dir(model):
        return model
    for d in model_candidates(task, root):
        if is_model_dir(d):
            return d
    return None


def find_local_dataset(task, dataset_dir=None, root=None):
    for d in dataset_candidates(task, dataset_dir, root):
        if is_dataset_dir(d):
            return d
    return None


def download_dataset(task, root=None, save=True):
    """Download the dataset from the Hub; try to save it to <root>/data/<task>."""
    import datasets

    repo = GLUE_HUB_REPO
    _say("no local dataset for %s, downloading %s / %s ..." % (task, repo, task))
    try:
        ds = datasets.load_dataset(repo, task)
    except Exception as e:
        raise SystemExit(
            "[assets] dataset download failed: %s\n"
            "[assets] This machine may not be able to reach the HuggingFace Hub.\n"
            "[assets] Prepare the data manually and point DATASET_DIR at it:\n"
            "           python -c \"import datasets; datasets.load_dataset('%s','%s').save_to_disk('./data/%s')\"\n"
            "           DATASET_DIR=./data/%s bash launch_%s.sh" % (e, repo, task, task, task, task)
        )
    if not save:
        return None, ds
    out = os.path.join(root or SCRIPT_DIR, "data", task)
    try:
        os.makedirs(os.path.dirname(out), exist_ok=True)
        if os.path.isdir(out):
            shutil.rmtree(out)
        ds.save_to_disk(out)
        _say("dataset saved to", out)
        return out, ds
    except Exception as e:  # read-only directory, etc.
        _say("could not save the dataset (%s); using the HF cache directly" % e)
        return None, ds


def _rel(path):
    """Prefer a short relative path (cwd, then the script directory) over an absolute one."""
    if not path:
        return path
    ap = os.path.abspath(path)
    for base in (os.getcwd(), SCRIPT_DIR):
        try:
            r = os.path.relpath(ap, base)
        except ValueError:      # different drive, etc.
            continue
        if not r.startswith(os.pardir):
            return r
    return ap


def resolve(task, model=None, dataset_dir=None, root=None, allow_download=True, save=True):
    """Locate model and dataset.

    Returns a dict(model=, dataset_dir=, offline=, model_is_local=, dataset_is_local=)
    model        a local directory, or a HuggingFace model id
    dataset_dir  a local dataset directory; None means "let load_dataset() take it
                 from the HF cache / network"
    offline      True when everything is local, i.e. TRANSFORMERS_OFFLINE=1 and
                 HF_HUB_OFFLINE=1 can be set safely
    """
    root = root or SCRIPT_DIR
    task = (task or DEFAULT_TASK).lower()
    model = model or os.environ.get("MODEL") or None
    dataset_dir = dataset_dir or os.environ.get("DATASET_DIR") or None

    # ---------- model ----------
    local_model = find_local_model(task, model, root)
    if local_model:
        model_path, model_is_local = local_model, True
    elif model and not is_model_dir(model):
        # an explicit hub id (or a path that does not exist): use it as given
        model_path, model_is_local = model, False
    else:
        model_path = HUB_MODEL_FALLBACK.get(task, "andeskyl/bert-base-cased-%s" % task)
        model_is_local = False

    # hub id that is not in the local cache yet -> needs the network
    if not model_is_local and allow_download and not hub_id_cached(model_path):
        _say("no local model for %s, downloading %s ..." % (task, model_path))
        try:
            from huggingface_hub import snapshot_download

            _say("model cached at", download_model(model_path))
        except Exception as e:
            _say("model download failed (%s); if this machine is offline, put the model "
                 "directory at %s and pass MODEL=..."
                 % (e, os.path.join(root, LOCAL_MODEL_DIRS.get(task, ["bert-%s" % task])[0])))

    # ---------- dataset ----------
    ds_dir = find_local_dataset(task, dataset_dir, root)
    downloaded = None
    if ds_dir is None and allow_download:
        ds_dir, downloaded = download_dataset(task, root, save)
    ds_is_local = ds_dir is not None

    # ---------- do we need the network at all? ----------
    offline_env = os.environ.get("OFFLINE")
    if offline_env in ("0", "1"):
        offline = offline_env == "1"
    else:
        offline = (model_is_local or hub_id_cached(model_path)) and ds_is_local

    res = dict(
        model=_rel(model_path),
        dataset_dir=_rel(ds_dir),
        offline=offline,
        model_is_local=model_is_local,
        dataset_is_local=ds_is_local,
    )
    _say("model =", res["model"], "(local)" if model_is_local else "(hub)")
    _say("dataset dir =", res["dataset_dir"] or "<HF cache>")
    _say("offline =", offline)
    return res, downloaded


def resolve_model(model=None, allow_download=True, root=None, default=None):
    """Generic single-model resolution: local directory -> HF cache -> Hub download.

    Used by scripts that just need one checkpoint (e.g. GPUs/ViT/GPT-2 demos).
    Returns dict(model=, offline=, model_is_local=).
    """
    model = model or os.environ.get("MODEL") or default or "openai-community/gpt2"
    is_local = is_model_dir(model)
    if not is_local and allow_download and not hub_id_cached(model):
        _say("no local model, downloading %s ..." % model)
        try:
            from huggingface_hub import snapshot_download

            _say("model cached at", download_model(model))
        except Exception as e:
            _say("model download failed (%s); if this machine is offline, pass MODEL=<local dir>"
                 % e)
    offline = is_local or hub_id_cached(model)
    res = dict(model=_rel(model) if is_local else model,
               offline=offline, model_is_local=is_local)
    _say("model =", res["model"], "(local)" if is_local else "(hub), offline =", offline)
    return res


def load_dataset(task, dataset_dir=None):
    """Load the dataset from dataset_dir, or fall back to load_dataset() (HF cache/network)."""
    import datasets

    task = (task or DEFAULT_TASK).lower()
    if is_dataset_dir(dataset_dir):
        print("[assets] load_from_disk(%s)" % dataset_dir, flush=True)
        return datasets.load_from_disk(dataset_dir)
    print("[assets] load_dataset(%s, %s)" % (GLUE_HUB_REPO, task), flush=True)
    return datasets.load_dataset(GLUE_HUB_REPO, task)


# ----------------------------- shell entry point -----------------------------
def _cli():
    import argparse
    import shlex

    p = argparse.ArgumentParser(
        description="Locate/fetch the model and dataset; print shell variables for eval"
    )
    p.add_argument("action", choices=["resolve", "resolve-model"])
    p.add_argument("--task", default=DEFAULT_TASK)
    p.add_argument("--model", default=None)
    p.add_argument("--dataset_dir", default=None)
    p.add_argument("--root", default=None)
    p.add_argument("--no_download", action="store_true", help="only look locally, never download")
    a = p.parse_args()

    # keep stdout clean for eval; progress messages go to stderr
    global _SAY_STREAM
    _SAY_STREAM = sys.stderr

    if a.action == "resolve-model":
        r = resolve_model(a.model, allow_download=not a.no_download, root=a.root)
        print("export MODEL=%s" % shlex.quote(r["model"]))
        if r["offline"]:
            print("export TRANSFORMERS_OFFLINE=1")
            print("export HF_HUB_OFFLINE=1")
        else:
            print("export TRANSFORMERS_OFFLINE=0")
            print("export HF_HUB_OFFLINE=0")
        return

    res, _ = resolve(
        a.task, a.model, a.dataset_dir, a.root,
        allow_download=not a.no_download,
    )
    print("export MODEL=%s" % shlex.quote(res["model"]))
    print("export DATASET_DIR=%s" % shlex.quote(res["dataset_dir"] or ""))
    if res["offline"]:
        print("export TRANSFORMERS_OFFLINE=1")
        print("export HF_HUB_OFFLINE=1")
    else:
        print("export TRANSFORMERS_OFFLINE=0")
        print("export HF_HUB_OFFLINE=0")


if __name__ == "__main__":
    _cli()
