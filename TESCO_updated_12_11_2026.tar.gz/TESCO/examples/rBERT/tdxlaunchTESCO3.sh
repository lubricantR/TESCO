export TASK_NAME=qnli
 export GLOO_SOCKET_IFNAME=tdx-tap0
 export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export MASTER_ADDR=192.168.100.1
export MASTER_PORT=29500
# asset resolution (local first, Hub only if missing); the remote TEE side needs no model/data
eval "$(python "$(dirname "$0")/assets.py" resolve --task "$TASK_NAME")"

LEN=${LEN:-128}

OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py --model_name_or_path $MODEL --task_name $TASK_NAME --len_data $LEN   --max_length $LEN --per_device_eval_batch_size 1 --output_dir eval_private/$TASK_NAME/1 &


sshpass -p '123456' ssh \
  -o StrictHostKeyChecking=accept-new \
  -p 10022 root@127.0.0.1 \
  'source ~/pytorch-env/bin/activate; GLOO_SOCKET_IFNAME=enp0s2 python ~/rTESCO/TESCO/launchteep2.py' &


OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp0.py --model_name_or_path $MODEL --task_name $TASK_NAME --len_data $LEN   --max_length $LEN --per_device_eval_batch_size 1 --output_dir eval_private/$TASK_NAME/1 
wait