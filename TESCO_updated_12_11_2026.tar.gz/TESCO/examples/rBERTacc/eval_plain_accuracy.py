"""Full plaintext accuracy (CPU or GPU, fast); serves as the reference for private inference.

Usage:
    python eval_plain_accuracy.py                      # default: sst2, len 128
    python eval_plain_accuracy.py --task_name qnli --len 128
    python eval_plain_accuracy.py --task_name qnli --len 64 --limit 500
"""

import argparse
import os

import datasets
import torch


def parse():
    p = argparse.ArgumentParser()
    p.add_argument("--task_name", default=os.environ.get("TASK_NAME", "sst2"))
    p.add_argument("--model_name_or_path", default=None)
    p.add_argument("--len", dest="len_data", type=int, default=128)
    p.add_argument("--limit", type=int, default=0, help="0 = whole split")
    p.add_argument("--bs", type=int, default=16)
    p.add_argument("--device", default="cuda:1")
    p.add_argument("--dataset_dir", default=None,
                   help="local dataset directory; if omitted it is resolved automatically "
                        "and downloaded from HuggingFace as a last resort")
    return p.parse_args()


def main():
    args = parse()

    # asset resolution: local first (project dir / HF cache), Hub only as a fallback
    import assets
    res, _ = assets.resolve(args.task_name, args.model_name_or_path, args.dataset_dir)
    model_path = res["model"]
    if res["offline"]:
        # must be set before importing transformers, otherwise it still goes online
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        os.environ["HF_HUB_OFFLINE"] = "1"

    from bert_custom import make_custom_bert
    from transformers import AutoTokenizer

    tok = AutoTokenizer.from_pretrained(model_path)
    model = make_custom_bert(model_path, seq_len=args.len_data)
    dev = args.device if torch.cuda.is_available() else "cpu"
    model = model.to(dev).float().eval()

    ds = assets.load_dataset(args.task_name, res["dataset_dir"])["validation"]
    if args.limit > 0:
        ds = ds.select(range(min(args.limit, len(ds))))
    print("samples =", len(ds), " max_length =", args.len_data, flush=True)

    if args.task_name == "qnli":
        k1, k2 = "question", "sentence"
    elif args.task_name == "sst2":
        k1, k2 = "sentence", None
    else:
        raise ValueError(args.task_name)

    correct = 0
    with torch.no_grad():
        for i in range(0, len(ds), args.bs):
            chunk = ds[i : i + args.bs]
            texts = (chunk[k1],) if k2 is None else (chunk[k1], chunk[k2])
            enc = tok(
                *texts, padding="max_length", max_length=args.len_data, truncation=True,
                return_tensors="pt",
            )
            logits = model(
                enc["input_ids"].to(dev),
                attention_mask=enc["attention_mask"].to(dev),
                token_type_ids=enc["token_type_ids"].to(dev),
            )
            pred = logits.float().argmax(-1).cpu()
            correct += int((pred == torch.tensor(chunk["label"])).sum())
            if (i // args.bs) % 20 == 0:
                seen = min(i + args.bs, len(ds))
                print("plain acc so far: %d/%d = %.4f" % (correct, seen, correct / seen), flush=True)
    print("PLAIN FINAL task=%s len=%d acc=%d/%d = %.4f" % (
        args.task_name, args.len_data, correct, len(ds), correct / len(ds)), flush=True)


if __name__ == "__main__":
    main()
