#!/bin/bash
# Same as launchTESCO3.sh (the SST-2 default) but explicitly without any bandwidth limiter.
# Kept as a separate name because older scripts refer to it.
export TASK_NAME=${TASK_NAME:-sst2}
exec bash "$(dirname "$0")/launch_sst2.sh" "$@"
