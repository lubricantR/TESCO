# coding=utf-8
# Modified by SHAFT's team: Private Text Classification on GLUE.
#
# Copyright 2021 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Testing a Transformers model in priavte for sequence classification on GLUE."""

import argparse
import json
import logging
import os
import time

import datasets
import evaluate
import torch
from datasets import load_dataset
from huggingface_hub import HfApi
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

import transformers
from transformers import (
    AutoConfig,
    AutoModelForSequenceClassification,
    AutoTokenizer,
    DataCollatorWithPadding,
    PretrainedConfig,
    default_data_collator,
)

from transformers.utils import check_min_version, send_example_telemetry
from transformers.utils.versions import require_version

import crypten as ct
from crypten.config import cfg
from multiprocess_launcher import MultiProcessLauncher

# Will error if the minimal version of Transformers is not installed. Remove at your own risks.
check_min_version("4.42.0.dev0")

require_version("datasets>=1.8.0", "To fix: pip install -r examples/pytorch/text-classification/requirements.txt")

task_to_keys = {
    "cola": ("sentence", None),
    "mnli": ("premise", "hypothesis"),
    "mrpc": ("sentence1", "sentence2"),
    "qnli": ("question", "sentence"),
    "qqp": ("question1", "question2"),
    "rte": ("sentence1", "sentence2"),
    "sst2": ("sentence", None),
    "stsb": ("sentence1", "sentence2"),
    "wnli": ("sentence1", "sentence2"),
}


def parse_args():
    parser = argparse.ArgumentParser(description="Finetune a transformers model on a text classification task")
    parser.add_argument(
        "--task_name",
        type=str,
        default=os.environ.get("TASK_NAME", "sst2"),
        help="The name of the glue task to evaluate on (default: sst2).",
        choices=list(task_to_keys.keys()),
    )
    parser.add_argument(
        "--validation_file", type=str, default=None, help="A csv or a json file containing the validation data."
    )
    parser.add_argument(
        "--num_data",
        type=int,
        default=-1,
        help="Number of validation data to run, set to -1 if run the whole dataset.",
    )
    parser.add_argument(
        "--len_data",
        type=int,
        default=-1,
        help="Sequence length of data to run, set to -1 if run the whole dataset.",
    )
    parser.add_argument(
        "--comp",
        action="store_true",
        help="If passed, estimate computation time (without communication).",
    )
    parser.add_argument(
        "--acc",
        action="store_true",
        help="If passed, evaluate private inference accuracy on the entire dataset.",
    )
    parser.add_argument(
        "--max_length",
        type=int,
        default=128,
        help=(
            "The maximum total input sequence length after tokenization. Sequences longer than this will be truncated,"
            " sequences shorter will be padded if `--pad_to_max_length` is passed."
        ),
    )
    parser.add_argument(
        "--pad_to_max_length",
        action="store_true",
        help="If passed, pad all samples to `max_length`. Otherwise, dynamic padding is used.",
    )
    parser.add_argument(
        "--model_name_or_path",
        type=str,
        default=None,
        help="Path to pretrained model or model identifier from huggingface.co/models. "
        "If omitted, it is resolved automatically (local directory first, otherwise a HuggingFace id).",
    )
    parser.add_argument(
        "--dataset_dir",
        type=str,
        default=None,
        help="Existing local dataset directory (save_to_disk format); if omitted it is resolved "
             "automatically and downloaded from HuggingFace as a last resort.",
    )
    parser.add_argument(
        "--use_slow_tokenizer",
        action="store_true",
        help="If passed, will use a slow tokenizer (not backed by the 🤗 Tokenizers library).",
    )
    parser.add_argument(
        "--per_device_eval_batch_size",
        type=int,
        default=8,
        help="Batch size (per device) for the evaluation dataloader.",
    )
    parser.add_argument("--output_dir", type=str, default=None, help="Where to store the output.")
    parser.add_argument("--seed", type=int, default=None, help="A seed for reproducible training.")
    parser.add_argument(
        "--trust_remote_code",
        type=bool,
        default=False,
        help=(
            "Whether or not to allow for custom models defined on the Hub in their own modeling files. This option "
            "should only be set to `True` for repositories you trust and in which you have read the code, as it will "
            "execute code present on the Hub on your local machine."
        ),
    )
    parser.add_argument(
        "--with_tracking",
        action="store_true",
        help="Whether to enable experiment trackers for logging.",
    )
    parser.add_argument(
        "--report_to",
        type=str,
        default="all",
        help=(
            'The integration to report the results and logs to. Supported platforms are `"tensorboard"`,'
            ' `"wandb"`, `"comet_ml"` and `"clearml"`. Use `"all"` (default) to report to all integrations. '
            "Only applicable when `--with_tracking` is passed."
        ),
    )
    parser.add_argument(
        "--ignore_mismatched_sizes",
        action="store_true",
        help="Whether or not to enable to load a pretrained model whose head dimensions are different.",
    )
    args = parser.parse_args()

    # Sanity checks
    if args.task_name is None and args.validation_file is None:
        raise ValueError("Need either a task name or a validation file.")
    else:
        if args.validation_file is not None:
            extension = args.validation_file.split(".")[-1]
            assert extension in ["csv", "json"], "`validation_file` should be a csv or a json file."

    return args


class _OfflineAccuracy:
    """Minimal drop-in for an `evaluate` metric: works with no Hub access and no cache."""

    def __init__(self):
        self.pred, self.ref = [], []

    def add_batch(self, predictions=None, references=None, **kwargs):
        self.pred.extend(predictions.tolist() if hasattr(predictions, "tolist") else list(predictions))
        self.ref.extend(references.tolist() if hasattr(references, "tolist") else list(references))

    def compute(self):
        if not self.ref:
            return {"accuracy": 0.0}
        return {"accuracy": sum(p == r for p, r in zip(self.pred, self.ref)) / len(self.ref)}


def main():
    script_start_time = time.time()
    args = parse_args()
    # Sending telemetry. Tracking the example usage helps us better allocate resources to maintain them. The
    # information sent is the one passed as arguments along with your Python/PyTorch versions.
    send_example_telemetry("run_glue_private", args)

    # Make one log on every process with the configuration for debugging.
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO,
    )


    datasets.utils.logging.set_verbosity_warning()
    transformers.utils.logging.set_verbosity_info()
    
    os.makedirs(args.output_dir, exist_ok=True)

    # ---- asset resolution: local first (project dir / HF cache), Hub only as a fallback ----
    import assets
    _res, _ = assets.resolve(
        args.task_name, args.model_name_or_path, args.dataset_dir
    )
    args.model_name_or_path = _res["model"]
    print("[assets] model=%s dataset_dir=%s offline=%s" % (
        _res["model"], _res["dataset_dir"], _res["offline"]), flush=True)
    #os.environ["TRANSFORMERS_OFFLINE"] = "1"
    if os.environ.get("TRANSFORMERS_OFFLINE") != "1":
        os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")   # only when going online
    os.environ["TRANSFORMERS_ENDPOINT"] = "https://hf-mirror.com"
    # Get the datasets: you can either provide your own CSV/JSON training and evaluation files (see below)
    # or specify a GLUE benchmark task (the dataset will be downloaded automatically from the datasets Hub).

    # For CSV/JSON files, this script will use as labels the column called 'label' and as pair of sentences the
    # sentences in columns called 'sentence1' and 'sentence2' if such column exists or the first two columns not named
    # label if at least two columns are provided.

    # If the CSVs/JSONs contain only one non-label column, the script does single sentence classification on this
    # single column. You can easily tweak this behavior (see below)

    # In distributed training, the load_dataset function guarantee that only one local process can concurrently
    # download the dataset.
    if args.task_name is not None:
        # prefer a local save_to_disk directory; otherwise take it from the HF cache / Hub
        raw_datasets = assets.load_dataset(args.task_name, _res["dataset_dir"])
    else:
        # Loading the dataset from local csv or json file.
        data_files = {}
        if args.validation_file is not None:
            data_files["validation"] = args.validation_file
        extension = args.validation_file.split(".")[-1]
        raw_datasets = load_dataset(extension, data_files=data_files,download_mode="reuse_dataset_if_exists")
    # See more about loading any type of standard or custom dataset at
    # https://huggingface.co/docs/datasets/loading_datasets.

    validation_key = "validation_matched" if args.task_name == "mnli" else "validation"

    # Labels
    if args.task_name is not None:
        is_regression = args.task_name == "stsb"
        if not is_regression:
            label_list = raw_datasets[validation_key].features["label"].names
            num_labels = len(label_list)
        else:
            num_labels = 1
    else:
        # Trying to have good defaults here, don't hesitate to tweak to your needs.
        is_regression = raw_datasets[validation_key].features["label"].dtype in ["float32", "float64"]
        if is_regression:
            num_labels = 1
        else:
            # A useful fast method:
            # https://huggingface.co/docs/datasets/package_reference/main_classes.html#datasets.Dataset.unique
            label_list = raw_datasets[validation_key].unique("label")
            label_list.sort()  # Let's sort it for determinism
            num_labels = len(label_list)
    
    # Load pretrained model and tokenizer
    #
    # In distributed training, the .from_pretrained methods guarantee that only one local process can concurrently
    # download model & vocab.
    print(args.model_name_or_path,
        num_labels,
        args.task_name,
        args.trust_remote_code)
    '''config = AutoConfig.from_pretrained(
        args.model_name_or_path,
        num_labels=num_labels,
        finetuning_task=args.task_name,
        trust_remote_code=args.trust_remote_code,
    )'''
    config = AutoConfig.from_pretrained(
        args.model_name_or_path,
        num_labels=num_labels,
        finetuning_task=args.task_name,
    )
    print(args.model_name_or_path, not args.use_slow_tokenizer, args.trust_remote_code)
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_name_or_path, use_fast=not args.use_slow_tokenizer, trust_remote_code=args.trust_remote_code
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    config.pad_token_id = tokenizer.pad_token_id

    model = AutoModelForSequenceClassification.from_pretrained(
        args.model_name_or_path,
        from_tf=bool(".ckpt" in args.model_name_or_path),
        config=config,
        ignore_mismatched_sizes=args.ignore_mismatched_sizes,
        trust_remote_code=args.trust_remote_code,
    )

    # Preprocessing the datasets
    if args.task_name is not None:
        sentence1_key, sentence2_key = task_to_keys[args.task_name]
    else:
        # Again, we try to have some nice defaults but don't hesitate to tweak to your use case.
        non_label_column_names = [name for name in raw_datasets[validation_key].column_names if name != "label"]
        if "sentence1" in non_label_column_names and "sentence2" in non_label_column_names:
            sentence1_key, sentence2_key = "sentence1", "sentence2"
        else:
            if len(non_label_column_names) >= 2:
                sentence1_key, sentence2_key = non_label_column_names[:2]
            else:
                sentence1_key, sentence2_key = non_label_column_names[0], None
    
    # Some models have set the order of the labels to use, so let's make sure we do use it.
    label_to_id = None
    if (
        model.config.label2id != PretrainedConfig(num_labels=num_labels).label2id
        and args.task_name is not None
        and not is_regression
    ):
        # Some have all caps in their config, some don't.
        label_name_to_id = {k.lower(): v for k, v in model.config.label2id.items()}
        if sorted(label_name_to_id.keys()) == sorted(label_list):
            print(
                f"The configuration of the model provided the following label correspondence: {label_name_to_id}. "
                "Using it!"
            )
            label_to_id = {i: label_name_to_id[label_list[i]] for i in range(num_labels)}
        else:
            print(
                "Your model seems to have been trained with labels, but they don't match the dataset: ",
                f"model labels: {sorted(label_name_to_id.keys())}, dataset labels: {sorted(label_list)}."
                "\nIgnoring the model labels as a result.",
            )
    elif args.task_name is None and not is_regression:
        label_to_id = {v: i for i, v in enumerate(label_list)}

    if label_to_id is not None:
        model.config.label2id = label_to_id
        model.config.id2label = {id: label for label, id in config.label2id.items()}
    elif args.task_name is not None and not is_regression:
        model.config.label2id = {l: i for i, l in enumerate(label_list)}
        model.config.id2label = {id: label for label, id in config.label2id.items()}

    # The private graph has a fixed shape, so whenever a target length is given we pad
    # to it. With dynamic padding only the few batches whose longest sample happens to be
    # exactly `len_data` would be evaluated (the rest get skipped below) -- silent traps.
    padding = "max_length" if (args.pad_to_max_length or args.len_data > 0) else False

    def preprocess_function(examples):
        # Tokenize the texts
        texts = (
            (examples[sentence1_key],) if sentence2_key is None else (examples[sentence1_key], examples[sentence2_key])
        )
        result = tokenizer(*texts, padding=padding, max_length=args.max_length, truncation=True)

        if "label" in examples:
            if label_to_id is not None:
                # Map labels to IDs (not necessary for GLUE tasks)
                result["labels"] = [label_to_id[l] for l in examples["label"]]
            else:
                # In all cases, rename the column to labels because the model will expect that.
                result["labels"] = examples["label"]
        return result

    processed_datasets = raw_datasets.map(
        preprocess_function,
        batched=True,
        remove_columns=raw_datasets["train"].column_names,
        desc="Running tokenizer on dataset",
    )

    eval_dataset = processed_datasets["validation_matched" if args.task_name == "mnli" else "validation"]

    # START_IDX lets a long run be resumed where the previous one stopped
    START_IDX = int(os.environ.get('START_IDX', '0'))
    if START_IDX > 0:
        print('resume from sample', START_IDX, flush=True)
        eval_dataset = eval_dataset.select(range(START_IDX, len(eval_dataset)))

    # DataLoaders creation:
    if args.pad_to_max_length:
        # If padding was already done ot max length, we use the default data collator that will just convert everything
        # to tensors.
        data_collator = default_data_collator
    else:
        # Otherwise, `DataCollatorWithPadding` will apply dynamic padding for us (by padding to the maximum length of
        # the samples passed). When using mixed precision, we add `pad_to_multiple_of=8` to pad all tensors to multiple
        # of 8s, which will enable the use of Tensor Cores on NVIDIA hardware with compute capability >= 7.5 (Volta).
        data_collator = DataCollatorWithPadding(tokenizer, pad_to_multiple_of=None)

    BATCH = int(os.environ.get('BATCH', '1'))
    print('batch size =', BATCH, flush=True)
    eval_dataloader = DataLoader(eval_dataset, collate_fn=data_collator,
                                 batch_size=args.per_device_eval_batch_size,
                                 drop_last=BATCH > 1)

    # Get the metric function (an offline fallback is used when `evaluate` cannot load anything)

    metric = None
    _offline = (os.environ.get("TRANSFORMERS_OFFLINE") == "1"
                or os.environ.get("HF_HUB_OFFLINE") == "1"
                or not os.path.isdir(os.path.expanduser("~/.cache/huggingface/evaluate/downloads")))
    if _offline:
        # no cached `evaluate` metric and no network: never attempt a download, use the local one
        metric = _OfflineAccuracy()
        print("[metric] offline, using the built-in accuracy", flush=True)
    elif args.task_name is not None:
        for _spec in ((os.path.expanduser("~/.cache/huggingface/evaluate/downloads"), args.task_name),
                      ("glue", args.task_name),
                      ("accuracy",)):
            try:
                metric = evaluate.load(*_spec)
                print("[metric] loaded", _spec, flush=True)
                break
            except Exception as _e:
                print("[metric] %s unavailable: %s" % (_spec, _e), flush=True)
        if metric is None:
            metric = _OfflineAccuracy()
            print("[metric] all options unavailable, using the built-in offline accuracy", flush=True)
    else:
        try:
            metric = evaluate.load("accuracy")
        except Exception:
            metric = _OfflineAccuracy()
    '''if os.environ["RANK"]=='1':
        device = "cpu"
    else:
        device="cpu"'''
    device='cuda:1'
    ct.init()
    
    #TESCO3 replace dummy = torch.zeros_like(model.dummy_inputs["input_ids"])
    _len = args.len_data if args.len_data > 0 else args.max_length

    # ------------------------------------------------------------------
    # By default we use a BERT assembled from basic modules (see bert_custom.py):
    #   * avoids input mis-binding caused by ONNX graph input names vs. their order;
    #   * avoids the crypten Sub(constant, encrypted) sign bug hit by (1.0-mask)*finfo.min;
    # use the original HF+ONNX path with USE_ORIG_MODEL=1
    # ------------------------------------------------------------------
    if os.environ.get('USE_ORIG_MODEL') == '1':
        print('using ORIGINAL HF model + ONNX export', flush=True)
    else:
        from bert_custom import make_custom_bert
        _nlayers = int(os.environ.get('LAYERS', '0')) or None
        model = make_custom_bert(
            args.model_name_or_path, nlayers=_nlayers, seq_len=_len, batch=BATCH
        )
        print('using CUSTOM BERT, layers =', len(model.bert.encoder.layer), flush=True)

    # TESCO3 accuracy settings (set at runtime only, the library is left untouched):
    #   sqrt_nr_iters: 7 -> 12; the embedding LayerNorm variance is tiny and 7 Newton
    #                  iterations are not enough
    #   softmax(ode): clip[-4,12]/iter16 -> clip[-4,16]/iter20
    #                 real attention scores reach +13.8, so an upper bound of 12 clips them,
    #                 and 16 iterations do not converge either
    #                 measured at len 64/128: 0.113 -> 0.019
    cfg.functions.sqrt_nr_iters = int(os.environ.get('SQRT_ITERS', '12'))
    cfg.functions.softmax_ode_lb = float(os.environ.get('SM_LB', '-4'))
    cfg.functions.softmax_ode_ub = float(os.environ.get('SM_UB', '16'))
    cfg.functions.softmax_ode_iter_num = int(os.environ.get('SM_ITER', '20'))
    if ct.communicator.get().get_rank() == 0:
        print('[cfg] sqrt_nr_iters=%s softmax lb=%s ub=%s iter=%s' % (
            cfg.functions.sqrt_nr_iters, cfg.functions.softmax_ode_lb,
            cfg.functions.softmax_ode_ub, cfg.functions.softmax_ode_iter_num), flush=True)

    BATCH = int(os.environ.get('BATCH', '1'))   # samples per private forward pass
    dummy = torch.zeros([BATCH, _len], dtype=torch.long)
    #model((dummy, dummy, dummy))
    #dummy = torch.zeros_like(model.dummy_inputs["input_ids"])
    print('dummy',dummy.shape)
    private_model = ct.nn.from_pytorch(model, (dummy, dummy, dummy)).encrypt().to(device)

    model.eval()
    samples_seen = 0
    # ---------------- accuracy bookkeeping ----------------
    MAX_SAMPLES = int(os.environ.get('MAX_SAMPLES', '64'))   # <=0 = whole split; ~16s/sample at 12L/seq64
    ACC_FILE = os.environ.get('ACC_FILE', '')               # append one line here every LOG_EVERY samples
    LOG_EVERY = int(os.environ.get('LOG_EVERY', '4'))        # how many samples between two log lines
    plain_correct = priv_correct = agree = 0
    diff_max = 0.0
    diff_sum = 0.0
    diff_cnt = 0
    last_log = 0
    n_skipped = 0
    t_start = time.time()
    for step, batch in enumerate(eval_dataloader):
        if args.len_data > 0 and batch["input_ids"].shape[1] != args.len_data:
            # should not happen with the padding above; keep it as a guard but make it visible
            n_skipped += 1
            if n_skipped <= 3:
                print('[warn] skipping batch %d: seq_len %d != len_data %d'
                      % (step, batch["input_ids"].shape[1], args.len_data), flush=True)
            continue

        inputs_enc = ct.cryptensor(batch["input_ids"]).to(device)
        attention_mask_enc = ct.cryptensor(batch["attention_mask"]).to(device)
        token_type_enc = ct.cryptensor(batch["token_type_ids"]).to(device)
        print('input shapes',inputs_enc.shape,attention_mask_enc.shape,token_type_enc.shape)
        from crypten.TESCO3time import flushtimer,r3time
        with ct.no_grad():
            flushtimer()
            outputs_enc = private_model(inputs_enc, attention_mask_enc, token_type_enc)
            r3time('inferring time')

        outputs = outputs_enc.get_plain_text().cpu()

        # ---------------- plaintext reference (cheap, computed for every batch) ----------------
        with torch.no_grad():
            ref = model(
                batch["input_ids"],
                attention_mask=batch["attention_mask"],
                token_type_ids=batch["token_type_ids"],
            )
        ref = ref.logits if hasattr(ref, 'logits') else ref
        ref = ref.float().cpu()

        _labels = batch["labels"].cpu()
        _pred_p = outputs.float().argmax(dim=-1)
        _pred_r = ref.argmax(dim=-1)
        _d = (ref - outputs.float()).abs()

        plain_correct += int((_pred_r == _labels).sum())
        priv_correct += int((_pred_p == _labels).sum())
        agree += int((_pred_r == _pred_p).sum())
        diff_max = max(diff_max, float(_d.max()))
        diff_sum += float(_d.sum())
        diff_cnt += _d.numel()
        samples_seen += int(_labels.shape[0])

        predictions = _pred_p if not is_regression else outputs.squeeze()
        if metric is not None:
            metric.add_batch(predictions=predictions, references=batch["labels"])

        _done = MAX_SAMPLES > 0 and samples_seen >= MAX_SAMPLES
        if (samples_seen - last_log >= LOG_EVERY or _done) \
                and ct.communicator.get().get_rank() == 0:
            last_log = samples_seen
            _line = 'ACC samples=%d [%d..%d]  plain=%.4f  private=%.4f  agree=%.4f  '\
                    'logit_diff max=%.5f mean=%.5f  elapsed=%.0fs' % (
                        samples_seen, START_IDX, START_IDX + samples_seen - 1,
                        plain_correct / samples_seen, priv_correct / samples_seen,
                        agree / samples_seen, diff_max, diff_sum / max(diff_cnt, 1),
                        time.time() - t_start)
            print(_line, flush=True)
            if ACC_FILE:
                with open(ACC_FILE, 'a') as _f:
                    _f.write('%s  %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), _line))
                    _f.flush()

        if _done:
            break

    if ct.communicator.get().get_rank() == 0:
        print('ACC FINAL samples=%d  plain=%.4f  private=%.4f  agree=%.4f  '
              'logit_diff max=%.5f mean=%.5f  elapsed=%.0fs' % (
                  samples_seen, plain_correct / max(samples_seen, 1),
                  priv_correct / max(samples_seen, 1), agree / max(samples_seen, 1),
                  diff_max, diff_sum / max(diff_cnt, 1), time.time() - t_start), flush=True)
        if n_skipped:
            print('[warn] %d batch(es) were skipped for shape mismatch' % n_skipped, flush=True)
    
    try:
        eval_metric = metric.compute()
        print(f"metric: {eval_metric}")
        print(f"running time: {time.time() - script_start_time}s")

        if args.output_dir is not None:
            all_results = {f"eval_{k}": v for k, v in eval_metric.items()}
            with open(os.path.join(args.output_dir, "all_results.json"), "w") as f:
                json.dump(all_results, f)
    except:
        return

if __name__ == "__main__":
    args = parse_args()
    if args.comp:
        # run without communication
        with cfg.temp_override({"cost.estimate_cost": True, "cost.estimate_mode": "comp"}):
            main()
    elif args.acc:
        # run without communication and cost printing
        with cfg.temp_override({"cost.estimate_cost": False}):
            main()
    else:
        # run with communication
        launcher = MultiProcessLauncher(2, main)
        launcher.start()
        launcher.join()
        launcher.terminate()
