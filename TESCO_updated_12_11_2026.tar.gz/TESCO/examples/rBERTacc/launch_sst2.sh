#!/bin/bash
# ================= SST-2 private inference (SST-2-finetuned model) =================
# Usage:
#   LEN=64 MAX_SAMPLES=0 LOG_EVERY=10 bash launch_sst2.sh
#     LEN          input length (SST-2 sentences are shorter than 64; plaintext acc 0.9243)
#     MAX_SAMPLES  at most this many samples, 0 = whole split (872)
#     LOG_EVERY    append one accuracy line to ACC_FILE every N samples
#     START_IDX    first sample to evaluate (for resuming, default 0)
#     BATCH        samples per private forward pass (1 = no batching)
#   MODEL / DATASET_DIR / OFFLINE / ACC_FILE / OUTPUT_DIR can all be overridden.
# Records: sst2_private_acc.txt    Full log: sst2_private_full.log
export TASK_NAME=sst2
# ---- asset resolution: use what is on this machine, fetch from the Hub only if missing ----
# MODEL=... DATASET_DIR=... to override; OFFLINE=0/1 to force online / offline
eval "$(python "$(dirname "$0")/assets.py" resolve --task "$TASK_NAME")"
export GLOO_SOCKET_IFNAME=tdx-tap0
# the library no longer hardcodes the rendezvous address: it must come from the environment
export MASTER_ADDR=${MASTER_ADDR:-127.0.0.1}
export MASTER_PORT=${MASTER_PORT:-29500}
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

export LEN=${LEN:-64}
export MAX_SAMPLES=${MAX_SAMPLES:-0}
export LOG_EVERY=${LOG_EVERY:-10}
export BATCH=${BATCH:-1}
export START_IDX=${START_IDX:-0}
export ACC_FILE=${ACC_FILE:-./sst2_private_acc.txt}

# the dataset directory is optional: only pass it if a local one was resolved
EXTRA_ARGS=""
[ -n "$DATASET_DIR" ] && EXTRA_ARGS="--dataset_dir $DATASET_DIR"
ARGS="--model_name_or_path $MODEL --task_name $TASK_NAME --len_data $LEN --max_length $LEN --pad_to_max_length --per_device_eval_batch_size ${BATCH:-1} $EXTRA_ARGS --output_dir ${OUTPUT_DIR:-eval_private/$TASK_NAME/1}"

# no bandwidth limiter for accuracy runs (limitipspeedcalaulatecomm.sh eats CPU and needs tc rules)
OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp1.py $ARGS &

python launchteep2.py &

OMP_NUM_THREADS=16 MKL_NUM_THREADS=16 python launchp0.py $ARGS

wait
