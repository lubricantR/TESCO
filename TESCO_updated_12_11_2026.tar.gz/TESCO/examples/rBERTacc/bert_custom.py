"""A BertForSequenceClassification assembled from basic modules (traceable by crypten).

Why this exists:
  1. The ONNX exporter names graph inputs after the function signature while their order
     follows first use, so feeding arguments positionally is easily mis-bound. Here the
     order in which forward() first uses the inputs matches the declared order exactly.
  2. crypten.nn.module.Sub has a sign bug for `Sub(constant, encrypted tensor)`
     (crypten/nn/module.py:1308 `-input[1].add(input[0])` == `-(x+c)`), which HF BERT hits
     with `(1.0 - attention_mask) * finfo.min`, making the attention bias a constant
     +20000 and the softmax saturate to a uniform distribution. We use
     `(mask - 1) * 10000` instead, which takes the correct `Sub(encrypted, constant)`
     branch and is mathematically equivalent (masked positions -> very negative).
  3. `finfo.min` (~-3.4e38) is far outside the fixed-point range, so it must be avoided.

Graph-friendly operator set: Embedding / MatMul / Add / Mul / Softmax / LayerNormalization /
Tanh / Gelu(Erf) / Reshape / Transpose -- all of them verified high-accuracy TESCO operators.

Parameter names are aligned with HF BertForSequenceClassification, so load_state_dict works.
"""

import math

import torch
import torch.nn as nn


class _SelfAttention(nn.Module):
    def __init__(self, hidden, num_heads):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = hidden // num_heads
        self.query = nn.Linear(hidden, hidden)
        self.key = nn.Linear(hidden, hidden)
        self.value = nn.Linear(hidden, hidden)

    def forward(self, x, bias):
        B, L, H = x.shape
        nh, dh = self.num_heads, self.head_dim
        q = self.query(x).view(B, L, nh, dh).transpose(1, 2)
        k = self.key(x).view(B, L, nh, dh).transpose(1, 2)
        v = self.value(x).view(B, L, nh, dh).transpose(1, 2)
        scores = torch.matmul(q, k.transpose(-1, -2)) * (1.0 / math.sqrt(dh)) + bias
        probs = torch.softmax(scores, -1)
        return torch.matmul(probs, v).transpose(1, 2).reshape(B, L, H)


class _Attention(nn.Module):
    def __init__(self, hidden, num_heads, eps):
        super().__init__()
        self.self = _SelfAttention(hidden, num_heads)
        self.output = nn.Module()
        self.output.dense = nn.Linear(hidden, hidden)
        self.output.LayerNorm = nn.LayerNorm(hidden, eps=eps)

    def forward(self, x, bias):
        return self.output.LayerNorm(x + self.output.dense(self.self(x, bias)))


class _Layer(nn.Module):
    def __init__(self, hidden, intermediate, num_heads, eps):
        super().__init__()
        self.attention = _Attention(hidden, num_heads, eps)
        self.intermediate = nn.Module()
        self.intermediate.dense = nn.Linear(hidden, intermediate)
        self.output = nn.Module()
        self.output.dense = nn.Linear(intermediate, hidden)
        self.output.LayerNorm = nn.LayerNorm(hidden, eps=eps)

    def forward(self, x, bias):
        x = self.attention(x, bias)
        h = nn.functional.gelu(self.intermediate.dense(x))
        return self.output.LayerNorm(x + self.output.dense(h))


def _lookup(table, ids):
    """crypten's TESCO3 embedding only accepts [1, num_token] indices; flatten, look up, restore."""
    B, L = ids.shape[0], ids.shape[1]
    out = table(ids.reshape(1, B * L))
    return out.reshape(B, L, out.shape[-1])


class _Embeddings(nn.Module):
    def __init__(self, vocab, hidden, max_pos, type_vocab, eps, seq_len, batch=1):
        super().__init__()
        self.word_embeddings = nn.Embedding(vocab, hidden)
        self.position_embeddings = nn.Embedding(max_pos, hidden)
        self.token_type_embeddings = nn.Embedding(type_vocab, hidden)
        self.LayerNorm = nn.LayerNorm(hidden, eps=eps)
        # fixed-length position indices: no dynamic arange / If nodes in the traced graph
        self.register_buffer(
            "position_ids", torch.arange(seq_len).unsqueeze(0).repeat(batch, 1),
            persistent=False,
        )

    def forward(self, ids, tt):
        h = self.word_embeddings(ids)
        h = h + self.token_type_embeddings(tt)
        return self.LayerNorm(h + self.position_embeddings(self.position_ids))


class CustomBertForSequenceClassification(nn.Module):
    """Fixed-shape inference BERT (parameter names aligned with HF)."""

    def __init__(self, config, nlayers=None, seq_len=128, num_labels=2, batch=1):
        super().__init__()
        nlayers = config.num_hidden_layers if nlayers is None else nlayers
        self.config = config
        self.bert = nn.Module()
        self.bert.embeddings = _Embeddings(
            config.vocab_size,
            config.hidden_size,
            config.max_position_embeddings,
            config.type_vocab_size,
            config.layer_norm_eps,
            seq_len,
            batch,
        )
        self.bert.encoder = nn.Module()
        self.bert.encoder.layer = nn.ModuleList(
            [
                _Layer(
                    config.hidden_size,
                    config.intermediate_size,
                    config.num_attention_heads,
                    config.layer_norm_eps,
                )
                for _ in range(nlayers)
            ]
        )
        self.bert.pooler = nn.Module()
        self.bert.pooler.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.classifier = nn.Linear(config.hidden_size, num_labels)

    def forward(self, input_ids, attention_mask, token_type_ids):
        # Order matters: the three graph inputs are first used in the order
        # input_ids -> attention_mask -> token_type_ids, matching how crypten feeds them.
        emb = self.bert.embeddings
        h = _lookup(emb.word_embeddings, input_ids)
        # Note: never write (1.0 - mask): it hits the crypten Sub(constant, encrypted) sign bug
        bias = (attention_mask.to(torch.float32) - 1.0) * 10000.0
        bias = bias.unsqueeze(1).unsqueeze(2)
        h = h + _lookup(emb.token_type_embeddings, token_type_ids)
        h = emb.LayerNorm(h + _lookup(emb.position_embeddings, emb.position_ids))
        for layer in self.bert.encoder.layer:
            h = layer(h, bias)
        pooled = torch.tanh(self.bert.pooler.dense(h[:, :1]))
        return self.classifier(pooled).view(-1, self.classifier.out_features)


def make_custom_bert(model_name_or_path, nlayers=None, seq_len=128, num_labels=None, batch=1):
    """Load HF checkpoint weights into an equivalent, crypten-friendly BERT."""
    from transformers import AutoConfig, AutoModelForSequenceClassification

    config = AutoConfig.from_pretrained(model_name_or_path)
    num_labels = config.num_labels if num_labels is None else num_labels
    hf = AutoModelForSequenceClassification.from_pretrained(model_name_or_path, config=config)
    model = CustomBertForSequenceClassification(
        config, nlayers=nlayers, seq_len=seq_len, num_labels=num_labels, batch=batch
    )
    missing, unexpected = model.load_state_dict(hf.state_dict(), strict=False)
    # when truncating layers, the unused higher-layer weights show up as "unexpected": fine
    bad_unexpected = [
        k for k in unexpected if ".encoder.layer." not in k and not k.endswith("position_ids")
    ]
    assert not bad_unexpected, "unexpected keys: %s" % bad_unexpected
    bad_missing = [k for k in missing if not k.endswith("position_ids")]
    assert not bad_missing, "missing keys: %s" % bad_missing
    model.eval()
    return model
