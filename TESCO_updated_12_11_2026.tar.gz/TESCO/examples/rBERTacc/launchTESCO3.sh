#!/bin/bash
# ================= Default entry point of this directory = SST-2 =================
# Defaults come from assets.py / launch_sst2.sh:
#   task      sst2
#   model     ./bert-sst2        (local directory, verified by assets.py)
#   dataset   ./sst2_hf          (local save_to_disk, verified by assets.py)
# Anything can still be overridden, e.g.
#   LEN=128 BATCH=4 MAX_SAMPLES=0 bash launchTESCO3.sh
#   MODEL=/path/to/other-bert DATASET_DIR=/path/to/data bash launchTESCO3.sh
# For QNLI use: bash launch_qnli.sh
export TASK_NAME=${TASK_NAME:-sst2}
exec bash "$(dirname "$0")/launch_sst2.sh" "$@"
