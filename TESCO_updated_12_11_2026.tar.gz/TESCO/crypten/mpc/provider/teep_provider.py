#!/usr/bin/env python3

# Copyright (c) Facebook, Inc. and its affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import logging

import crypten
import crypten.communicator as comm
import torch
import torch.distributed as dist
from crypten.common.rng import generate_kbit_random_tensor, generate_random_ring_element
from crypten.common.util import count_wraps
from crypten.mpc.primitives import ArithmeticSharedTensor, BinarySharedTensor

from .provider import TupleProvider

from crypten.mpc.TESCOrand import random_int_tensor

from crypten.config import cfg
TEEP_FUNCTIONS = ["additive", "square", "binary", "wraps", "B2A"]
from crypten.TESCO3time import *
def teep_request(func_name, device, *args, **kwargs):
    if device is not None:
        device = str(device)
    message = {
        "function": func_name,
        "device": device,
        "args": args,
        "kwargs": kwargs,
    }
    ttp_rank=2
    #print('teep request',message)
    comm.get().send_obj(message, ttp_rank, comm.get().ttp_group)

    #size = comm.get().recv_obj(ttp_rank, comm.get().ttp_group)
    #result = torch.empty(size, dtype=torch.long, device=device)
    #comm.get().broadcast(result, ttp_rank, comm.get().ttp_group)

    return 
def TESCO3teemulbit2(shzero):
    #print('tee x1s',shzero.shape)
    shape=shzero.shape;dtype=shzero.dtype
    with r3namedtime('tee msb gen rand'):
        tx1=random_int_tensor(shape,dtype,comm.get().gseed1)
        ty1=random_int_tensor(shape,dtype,comm.get().gseed1)
        tu1=random_int_tensor(shape,dtype,comm.get().gseed1)
    with r3namedtime('tee msb recv x0y0'):
        x0=torch.zeros_like(shzero);dist.recv(x0,0)
        y0=torch.zeros_like(shzero);dist.recv(y0,0)
    with r3namedtime('tee msb cal u0'):
        #u0=(x0^tx1)&(y0^ty1)^tu1
        u0=(x0&ty1)^(tx1&y0)^tu1
    with r3namedtime('tee msb send u0'):
        dist.send(u0,0)

    return
def TESCO3teemuladditive2(x0shape,y0shape,zshape,op ,*args, **kwargs):
    #print('tee s',shzero.shape)
    dtype=torch.long
    tx1=random_int_tensor(x0shape,dtype,comm.get().gseed1)
    ty1=random_int_tensor(y0shape,dtype,comm.get().gseed1)
    tu1=random_int_tensor(zshape,dtype,comm.get().gseed1)
    
    x0=torch.zeros_like(tx1);dist.recv(x0,0)
    #print('teep get x0',x0)
    y0=torch.zeros_like(ty1);dist.recv(y0,0)
    #print('teep get y0',y0)
    u0=(x0+tx1)*(y0+ty1)-tu1

    dist.send(u0,0)
    #print('tee e',u0)
    return
def TESCO3teetripleadditive2(x0shape,y0shape,op,*args, **kwargs):
    #print('tee s',shzero.shape)
    dtype=torch.long
    x0=torch.empty(x0shape,dtype=dtype);
    y0=torch.empty(y0shape,dtype=dtype);
    hrx0=dist.irecv(x0,0)
    hry0=dist.irecv(y0,0)
    with r3namedtime('tee generate tx1 ty1'):
        tx1=random_int_tensor(x0shape,dtype,comm.get().gseed1)
        ty1=random_int_tensor(y0shape,dtype,comm.get().gseed1)
    
    
    hrx0.wait();hry0.wait()
    #print('teep get x0',x0)
    
    #print('teep get y0',y0)
    with r3namedtime('tee triple mul'):
        #u0=getattr(torch, op)((x0+tx1),(y0+ty1),*args, **kwargs)
        u0=getattr(torch, op)((x0),(ty1),*args, **kwargs)+getattr(torch, op)((tx1),(y0),*args, **kwargs)
    with r3namedtime('tee gen tu1'):
        tu1=random_int_tensor(u0.shape,u0.dtype,comm.get().gseed1)
    u0-=tu1;
    dist.send(u0,0)
    #print('tee e',u0)
    return
def TESCO3teesin2(x0shape,*args, **kwargs):
    dtype=torch.long
    x0=torch.empty(x0shape,dtype=dtype);
    hrx0=dist.irecv(x0,0)
    
    with r3namedtime('teesin generate tx u'):
        tx=random_int_tensor(x0shape,dtype,comm.get().gseed1)
        tu=random_int_tensor(x0shape,dtype,comm.get().gseed1)
    
    hrx0.wait();

    dist.send(x0-tx-tu,0)

    return
class TEEPServer:
    TERMINATE = -1

    def __init__(self):
        """Initializes a Trusted Third Party server that receives requests"""
        # Initialize connection
        crypten.init()
        self.ttp_group = comm.get().ttp_group
        #self.comm_group = comm.get().ttp_comm_group
        self.device = "cpu"
        #self._setup_generators()
        ttp_rank = comm.get().get_ttp_rank()
        
        logging.info("TEEPServer Initialized")
        print('TEE at rank ',ttp_rank)
        import sys
        sys.path.insert(0, '/root')
        try:
            while True:
                # Wait for next request from client
                message = comm.get().recv_obj(0,self.ttp_group)
                logging.info("TEEP Message received: %s" % message)
                #print('teep get',message)
                if message == "terminate":
                    logging.info("TTPServer shutting down.")
                    return

                function = message["function"]
                device=message["device"]
                args = message["args"]
                kwargs = message["kwargs"]

                self.device = device
                
                result = getattr(self, function)(*args, **kwargs)

                #comm.get().send_obj(result.size(), 0, self.ttp_group)
                #comm.get().broadcast(result, ttp_rank, self.comm_group)
        except RuntimeError as err:
            r3timeprintall()
            logging.info("Encountered Runtime error. TTPServer shutting down:")
            logging.info(f"{err}")

    

    

    def teeTESCO3ltz(self,size,xshape,*args, **kwargs):
        c=torch.zeros(size,dtype=torch.uint8)
        shift = torch.iinfo(torch.long).bits
        #print('tee ltz invoke')
        if cfg.TESCO3supermsb==0:
            for i in range(2*(shift-1)):
                TESCO3teemulbit2(c);
        else:
            for i in range(shift-1):
                TESCO3teemulbit2(c);
        b0=torch.zeros(xshape,dtype=torch.uint8);
        a0=torch.zeros(xshape,dtype=torch.long);
        dist.recv(b0,0);dist.recv(a0,0);

        ta1=random_int_tensor(a0.shape,a0.dtype,comm.get().gseed1)
        tb1=random_int_tensor(b0.shape,b0.dtype,comm.get().gseed1)
        u1=random_int_tensor(a0.shape,a0.dtype,comm.get().gseed1)
        #print('abuv=',ta1,tb1,u1)
        dist.send(((b0+tb1)&1)*(a0+ta1)-u1,0)

    def teeTESCO3mul(self,x0shape,y0shape,zshape,op ,*args, **kwargs):
        
        TESCO3teemuladditive2(x0shape,y0shape,zshape,op ,*args, **kwargs)

    def teeTESCO3triple(self,x0shape,y0shape,op ,*args, **kwargs):
        TESCO3teetripleadditive2(x0shape,y0shape,op,*args, **kwargs)
    def teeTESCO3sin(self,x0shape,*args,**kwargs):
        TESCO3teesin2(x0shape,*args,**kwargs)

    def teeTESCO3embedding(self, num_token, voc_size, num_embedding, *args, **kwargs):
        dtype = torch.long
        voc_size=num_token
        WINDOW = 32
        
        recv_bufs = [torch.empty((voc_size, num_embedding), dtype=dtype) for _ in range(WINDOW)]
        recv_reqs = [None] * WINDOW

        # r: (num_token,)
        r = random_int_tensor([num_token], dtype, comm.get().gseed1) % voc_size

        ans = torch.empty((num_token, num_embedding), dtype=dtype)

       
        pre = min(WINDOW, num_token)
        for i in range(pre):
            slot = i % WINDOW
            recv_reqs[slot] = dist.irecv(recv_bufs[slot], src=0)

        
        for i in range(num_token):
            slot = i % WINDOW

            
            with r3namedtime('TEE waiting'):
                recv_reqs[slot].wait()

            
            nxt = i + WINDOW
            if nxt < num_token:
                recv_reqs[slot] = dist.irecv(recv_bufs[slot], src=0)

            
            with r3namedtime('TEE rand'):
                r1 = random_int_tensor([num_embedding], dtype, comm.get().gseed1)

            
            row_idx = int(r[i].item())
            erdta = recv_bufs[slot][row_idx]      # shape: (num_embedding,)

            x0 = erdta + r1
            ans[i].copy_(x0)

            print('tee t3', i)

        
        dist.send(ans, dst=0)
    '''def teeTESCO3embedding(self,num_token,voc_size,num_embedding,*args, **kwargs):
        dtype=torch.long
        dta=torch.empty((voc_size,num_embedding),dtype=dtype);
        recvdta=torch.empty((voc_size,num_embedding),dtype=dtype);
        r=random_int_tensor([num_token],dtype,comm.get().gseed1)%voc_size
        sends=[]
        dtas=[dta,recvdta]
        cur=0
        ans=torch.zeros((num_token,num_embedding),dtype=dtype)
        for i in range(num_token):
            if i==0:
                hr=dist.irecv(dtas[cur],0)
            #hr=dist.irecv(dta,0)
            with r3namedtime('TEE rand'):
                r1=random_int_tensor([num_embedding],dtype,comm.get().gseed1)
                er=torch.zeros((voc_size,1));er[r[i].item()][0]=1;
            with r3namedtime('TEE waiting'):
                hr.wait()
            hr=dist.irecv(dtas[1-cur],0)
            erdta=(dtas[cur]*er).sum(dim=0)
            #erdta=(dta*er).sum(dim=0)
            x0=erdta+r1
            
            
            
            ans[i]=x0
            print('tee t3',i)
            cur=1-cur
        
        dist.send(ans,0)'''
            
    def teeTESCO3embeddingshuffle(self,num_token,voc_size,num_embedding,*args, **kwargs):
        
        import testobviousshuffle
        #print('TEE embd s')
        dtype=torch.long
        waddwr1=torch.empty((voc_size,num_embedding),dtype=dtype);
        hwaddwr1=dist.irecv(waddwr1,0)
        pier=random_int_tensor([voc_size],dtype,comm.get().gseed1);print('pier:',pier)
        wr2=random_int_tensor(waddwr1.shape,dtype,comm.get().gseed1)*0
        
        #print('TEE embd callshuffle s')
        hwaddwr1.wait()
        piewaddwr1=testobviousshuffle.secure_shuffle(waddwr1,pier)
        
        dist.send(piewaddwr1+wr2,0)
        #print('TEE embd e')
        
    def teeTESCO3embeddingold(self,num_token,voc_size,num_embedding,*args, **kwargs):
        dtype=torch.long
        dta=torch.empty((voc_size,num_embedding),dtype=dtype);
        recvdta=torch.empty((voc_size,num_embedding),dtype=dtype);
        r=random_int_tensor([num_token],dtype,comm.get().gseed1)
        sends=[]
        dtas=[dta,recvdta]
        cur=0
        
        for i in range(num_token):
            if i==0:
                hr=dist.irecv(dtas[cur],0)
            with r3namedtime('TEE rand'):
                R1=random_int_tensor((voc_size,num_embedding),dtype,comm.get().gseed1)
            hr.wait()
            #if i!=num_token-1:
            #    hr=dist.irecv(recvdta,0)
            hr=dist.irecv(dtas[1-cur],0)
            with r3namedtime('TEE rolling'):
                dta2=torch.roll(dtas[cur],shifts=-r[i].item(),dims=0)+R1
            
            sends.append(dist.isend(dta2[0],0))
            cur=1-cur
        for i in range(num_token):
            sends[i].wait()
    def teeTESCO3embeddingoldest(self,num_token,voc_size,num_embedding,*args, **kwargs):
        dtype=torch.long
        waddwr1=torch.empty((voc_size,num_embedding),dtype=dtype);
        
        r1=random_int_tensor([num_token],dtype,comm.get().gseed1)
        #print('Ptee:r1',r1,'numtoken',num_token)
        for i in range(num_token):
            
            hr=dist.irecv(waddwr1,0)
            wr2=random_int_tensor((voc_size,num_embedding),dtype,comm.get().gseed1)
            hr.wait()
            waddwr1=torch.roll(waddwr1,shifts=-r1[i].item(),dims=0)
            waddwr1+=wr2
            #print('teewr2',wr2[:,0:10],'\nteep emb ssend')
            dist.send(waddwr1,0)
            #print('teep emb esend')
    def teeTESCO3embedding_super(self, num_token, voc_size, num_embedding, *args, **kwargs):
        shape = (voc_size, num_embedding)

        keys = random_int_tensor(
            [voc_size], torch.long, comm.get().gseed1
        )
        pi = torch.argsort(keys)
        m1 = random_int_tensor(shape, torch.long, comm.get().gseed1)

        masked_weight = torch.empty(shape, dtype=torch.long)
        dist.recv(masked_weight, src=0)
        dist.send(masked_weight.index_select(0, pi) + m1, dst=0) 

    def additive(self, size0, size1, op, *args, **kwargs):

        # Add all shares of `a` and `b` to get plaintext `a` and `b`
        #a = self._get_additive_PRSS(size0)
        #b = self._get_additive_PRSS(size1)

        c = getattr(torch, op)(a, b, *args, **kwargs)

        # Subtract all other shares of `c` from plaintext value of `c` to get `c0`
        c0 = c - self._get_additive_PRSS(c.size(), remove_rank=True)
        return c0

    def square(self, size):
        # Add all shares of `r` to get plaintext `r`
        r = self._get_additive_PRSS(size)
        r2 = r.mul(r)
        return r2 - self._get_additive_PRSS(size, remove_rank=True)

    def binary(self, size0, size1):
        # xor all shares of `a` and `b` to get plaintext `a` and `b`
        a = self._get_binary_PRSS(size0)
        b = self._get_binary_PRSS(size1)

        c = a & b

        # xor all other shares of `c` from plaintext value of `c` to get `c0`
        c0 = c ^ self._get_binary_PRSS(c.size(), remove_rank=True)
        return c0

    def wraps(self, size):
        r = [generate_random_ring_element(size, generator=g) for g in self.generators]
        theta_r = count_wraps(r)

        return theta_r - self._get_additive_PRSS(size, remove_rank=True)

    def B2A(self, size):
        rB = self._get_binary_PRSS(size, bitlength=1)

        # Subtract all other shares of `rA` from plaintext value of `rA`
        rA = rB - self._get_additive_PRSS(size, remove_rank=True)

        return rA
