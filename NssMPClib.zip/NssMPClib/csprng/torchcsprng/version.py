__version__ = '1.0.0a0+470cb37'
git_version = '470cb37be7f4a5d085b178595c3a490753e631f2'
