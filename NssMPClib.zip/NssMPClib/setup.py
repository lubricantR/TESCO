import os

from setuptools import setup, find_packages

path = os.path.dirname(os.path.abspath(__file__))

setup(
    name="NssMPClib",
    version="1.0",
    author="XDU NSS Lab",
    author_email="nss@xidian.edu.cn",
    description="NssMPClib，（Arithmetic Secret Sharing，ASS）（Function Secret Sharing，FSS），。",
    url="https://gitcode.com/openHiTLS/NssMPClib",
    license="MIT",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[f'torchcsprng @ file://localhost/{path}/csprng'],
)
