#  This file is part of the NssMPClib project.
#  Copyright (c) 2024 XDU NSS lab,
#  Licensed under the MIT license. See LICENSE in the project root for license information.

from NssMPC.application.neural_network.party.neural_network_party import PartyNeuralNetwork2PC, PartyNeuralNetWork3PC
