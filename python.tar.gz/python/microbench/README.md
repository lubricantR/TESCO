This directory contains examples demonstrating how to benchmark the proposed building blocks in BumbleBee, including the matrix multipliaction, softmax, and piecewise activations.
