import argparse
import json
import time
import jax
import jax.nn as jnn
import numpy as np
import spu.utils.distributed as ppd
import spu.spu_pb2 as spu_pb2
import spu.intrinsic as si

copts = spu_pb2.CompilerOptions()
# enable x / broadcast(y) -> x * broadcast(1/y) which accelerate the softmax
copts.enable_optimize_denominator_with_broadcast = True
def _gelu(x):
    return si.spu_gelu(x)
def main():
    parser = argparse.ArgumentParser(description='SPU GELU Network Benchmark')
    parser.add_argument('-c', '--config', default='examples/python/conf/2pc.json')
    parser.add_argument('--size', type=int, default=10000000, help='Input size (number of elements)')
    parser.add_argument('--loop', type=int, default=1, help='Number of benchmark iterations')
    args = parser.parse_args()

    print(f"Loading config from: {args.config}")
    with open(args.config, 'r') as f:
        conf = json.load(f)

    # Initialize the SPU cluster
    print("Initializing SPU cluster...")
    ppd.init(conf['nodes'], conf['devices'])

    # Generate synthetic data
    print(f"Generating random input data (size={args.size})...")
    np.random.seed(42)
    x_np = np.random.randn(args.size).astype(np.float64)

    # Define the function to run on SPU
    # We use standard jax.nn.gelu which decomposes into supported SPU operations.
    # This avoids potential intrinsic type checks issues while still benchmarking the operation.
    #jnn.gelu=si.spu_gelu
    def gelu_fn(x):
        #return jnn.relu(x)
        print('before',x)
        return _gelu(x)

    # Transfer data to P1 (Public)
    print("Transferring data to P1...")
    x_p1 = ppd.device('P1')(lambda t: t)(x_np)
    x_spu = ppd.device('SPU')(lambda t: t)(x_np)
    # Compile/Warmup
    #print("Compiling and warming up on SPU...")
    # Note: First run triggers compilation
    #y_spu = ppd.device('SPU')(gelu_fn)(x_p1)
    #_ = ppd.get(y_spu)

    # Benchmark Loop
    print(f"Starting benchmark ({args.loop} iterations)...")
    latencies = []
    
    for i in range(args.loop):
        start = time.time()
        
        # Schedule SPU task
        print(x_spu)
        y_spu = ppd.device('SPU')(gelu_fn)(x_spu)
        #y_spu=_gelu(x_spu)
        # Fetch result to synchronize and measure end-to-end time
        # This includes SPU computation + Network overhead
        _ = ppd.get(y_spu)
        
        end = time.time()
        latencies.append(end - start)
        print(f"Iter {i+1}/{args.loop}: {latencies[-1]:.4f}s")

    avg_latency = sum(latencies) / len(latencies)
    print(f"\nBenchmark Results:")
    print(f"Input Size: {args.size} elements")
    print(f"Avg Latency: {avg_latency:.4f} seconds")
    print(f"Throughput: {args.size / avg_latency:.2f} elements/sec")

    # Correctness Check
    print("\nVerifying correctness...")
    y_np = ppd.get(y_spu)
    print(y_np.shape)
    expected = jnn.gelu(x_np)
    # Allow for some error due to fixed-point precision
    diff = np.max(np.abs(y_np - expected))
    print(f"Max absolute difference vs CPU: {diff}")
    
    if diff > 1e-2:
        print("WARNING: Difference is large, check precision settings.")
    else:
        print("Correctness verified.")

if __name__ == '__main__':
    main()
