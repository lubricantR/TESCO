import argparse
import json
import time
from contextlib import contextmanager

import jax
import jax.numpy as jnp
import jax.nn as jnn
import flax.linen as fnn
import numpy as np
import spu.utils.distributed as ppd
import spu.spu_pb2 as spu_pb2
import spu.intrinsic as intrinsic

def _softmax(x, axis=-1, where=None, initial=None):
    
    x_max = jnp.max(x, axis=axis, where=where, initial=initial, keepdims=True)
    
    x = x - x_max
    # spu.neg_exp (or intrinsic.spu_neg_exp) is optimized for SPU
    # It clips values that are too large/small for the approximation
    nexp = intrinsic.spu_neg_exp(x)
    
    divisor = jnp.sum(nexp, axis=axis, where=where, keepdims=True)
    #return x
    return nexp +x# (divisor+0.001)

@contextmanager
def hijack(enabled=True):
    if not enabled:
        yield
        return
    
    # Save original functions
    jnn_sm = jnn.softmax
    fnn_sm = fnn.softmax
    
    # Replace with optimized SPU version
    jnn.softmax = _softmax
    fnn.softmax = _softmax
    
    try:
        yield
    finally:
        # Restore original functions
        jnn.softmax = jnn_sm
        fnn.softmax = fnn_sm

class SoftmaxModel(fnn.Module):
    @fnn.compact
    def __call__(self, x):
        return jnn.softmax(x)

def main():
    parser = argparse.ArgumentParser(description='SPU Softmax Network Benchmark')
    parser.add_argument('-c', '--config', default='examples/python/conf/2pc.json')
    parser.add_argument('--rows', type=int, default=960, help='Input rows')
    parser.add_argument('--cols', type=int, default=180, help='Input columns')
    parser.add_argument('--loop', type=int, default=10, help='Number of benchmark iterations')
    args = parser.parse_args()

    print(f"Loading config from: {args.config}")
    with open(args.config, 'r') as f:
        conf = json.load(f)

    # Initialize the SPU cluster
    print("Initializing SPU cluster...")
    ppd.init(conf['nodes'], conf['devices'])

    # Generate synthetic data
    print(f"Generating random input data ({args.rows}x{args.cols})...")
    np.random.seed(42)
    # Scale input to verify stability/precision with larger values similar to softmax.py
    

    # Initialize Flax Model
    model = SoftmaxModel()
    key = jax.random.PRNGKey(0)
    # Initialize parameters (though empty for Softmax)
    x_np = jax.random.normal(key, (args.rows, args.cols), dtype=jnp.float32) * 8.0
    x_np = x_np.astype(jnp.int32)
    variables = model.init(key, jnp.ones((1, args.cols)))
    
    # Compiler options to enable broadcast optimization for division
    copts = spu_pb2.CompilerOptions()
    copts.enable_optimize_denominator_with_broadcast = True

    # Transfer data to P1 (Public)
    print("Transferring data to P1...")
    x_p1 = ppd.device('SPU')(lambda t: t)(x_np)
    # Transfer params to P2 (just to follow 2PC pattern usually, or P1)
    # Here we put params on P1 as well for simplicity or P2
    params_p2 = ppd.device('P2')(lambda t: t)(variables)

    def model_forward(params, x):
        with hijack():
            return model.apply(params, x)

    # Compile/Warmup
    print("Compiling and warming up on SPU...")
    # Note: First run triggers compilation
    y_spu = ppd.device('SPU')(model_forward, copts=copts)(params_p2, x_p1)
    _ = ppd.get(y_spu)

    # Benchmark Loop
    print(f"Starting benchmark ({args.loop} iterations)...")
    latencies = []
    
    for i in range(args.loop):
        start = time.time()
        
        # Schedule SPU task
        y_spu = ppd.device('SPU')(model_forward, copts=copts)(params_p2, x_p1)
        
        # Fetch result to synchronize and measure end-to-end time
        _ = ppd.get(y_spu)
        
        end = time.time()
        latencies.append(end - start)
        print(f"Iter {i+1}/{args.loop}: {latencies[-1]:.4f}s")

    avg_latency = sum(latencies) / len(latencies)
    print(f"\nBenchmark Results:")
    print(f"Input Shape: ({args.rows}, {args.cols})")
    print(f"Avg Latency: {avg_latency:.4f} seconds")
    print(f"Throughput: {(args.rows * args.cols) / avg_latency:.2f} elements/sec")

    # Correctness Check
    print("\nVerifying correctness...")
    y_np = ppd.get(y_spu)
    # Use local model execution for expected result
    # No hijack needed for CPU ground truth (uses standard jax.nn.softmax)
    expected = model.apply(variables, x_np)
    
    # Allow for some error due to fixed-point precision and approximation
    diff = np.max(np.abs(y_np - expected))
    print(f"Max absolute difference vs CPU: {diff}")
    
    # Threshold might need adjustment depending on approximation precision
    if diff > 1e-2:
        print("WARNING: Difference is large, check precision settings.")
    else:
        print("Correctness verified.")

if __name__ == '__main__':
    main()
