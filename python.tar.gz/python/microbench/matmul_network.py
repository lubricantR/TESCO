import argparse
import json
import time

import jax.numpy as jnp
import numpy as np
import spu.utils.distributed as ppd
import spu.spu_pb2 as spu_pb2

def main():
    parser = argparse.ArgumentParser(description='SPU Matmul Network Benchmark')
    parser.add_argument('-c', '--config', default='examples/python/conf/2pc.json')
    parser.add_argument('--m', type=int, default=128, help='M dimension')
    parser.add_argument('--k', type=int, default=768, help='K dimension')
    parser.add_argument('--n', type=int, default=2304, help='N dimension')
    parser.add_argument('--loop', type=int, default=5, help='Number of benchmark iterations')
    args = parser.parse_args()

    print(f"Loading config from: {args.config}")
    with open(args.config, 'r') as f:
        conf = json.load(f)

    # Initialize the SPU cluster
    print("Initializing SPU cluster...")
    ppd.init(conf['nodes'], conf['devices'])

    # Generate synthetic data
    print(f"Generating random input data ({args.m}x{args.k} and {args.k}x{args.n})...")
    np.random.seed(42)
    # Using integers similar to matmul.py to avoid precision issues during verification if desired, 
    # or stick to float for performance bench. 
    # Let's use standard floats for general performance testing.
    x_np = np.random.randn(args.m, args.k).astype(np.float32)
    y_np = np.random.randn(args.k, args.n).astype(np.float32)

    # Define the function to run on SPU
    def spu_matmul(x, y):
        return jnp.dot(x, y)

    # Transfer data to P1 and P2
    # Simulate a scenario where P1 holds X and P2 holds Y (common in MPC)
    print("Transferring data to P1 and P2...")
    x_p1 = ppd.device('P1')(lambda t: t)(x_np)
    y_p2 = ppd.device('P2')(lambda t: t)(y_np)

    # Compile/Warmup
 

    # Benchmark Loop
    print(f"Starting benchmark ({args.loop} iterations)...")
    latencies = []
    
    for i in range(args.loop):
        start = time.time()
        
        # Schedule SPU task
        z_spu = ppd.device('SPU')(spu_matmul)(x_p1, y_p2)
        
        # Fetch result to synchronize and measure end-to-end time
        _ = ppd.get(z_spu)
        
        end = time.time()
        latencies.append(end - start)
        print(f"Iter {i+1}/{args.loop}: {latencies[-1]:.4f}s")

    avg_latency = sum(latencies) / len(latencies)
    print(f"\nBenchmark Results:")
    print(f"Input Shapes: ({args.m}x{args.k}) @ ({args.k}x{args.n})")
    print(f"Avg Latency: {avg_latency:.4f} seconds")
    ops = 2 * args.m * args.k * args.n  # Approximate FLOPs for Matmul
    print(f"Throughput: {ops / avg_latency / 1e9:.2f} GFLOPS (effective)")

    # Correctness Check
    print("\nVerifying correctness...")
    z_np = ppd.get(z_spu)
    expected = jnp.dot(x_np, y_np)
    
    # Allow for some error due to fixed-point precision
    # Relative error might be more appropriate for large values
    diff = np.max(np.abs(z_np - expected))
    # Also check relative error if values are large
    max_val = np.max(np.abs(expected))
    rel_err = diff / (max_val + 1e-7)
    
    print(f"Max absolute difference vs CPU: {diff}")
    print(f"Max relative error vs CPU: {rel_err}")
    
    if rel_err > 1e-2:
        print("WARNING: Difference is large, check precision settings.")
    else:
        print("Correctness verified.")

if __name__ == '__main__':
    main()
