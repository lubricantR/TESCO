import argparse
import json
import time
from contextlib import contextmanager

import jax
import jax.numpy as jnp
import flax.linen as fnn
import numpy as np
import spu.utils.distributed as ppd
import spu.spu_pb2 as spu_pb2

# Standard LayerNorm using Flax
class LayerNormModel(fnn.Module):
    epsilon: float = 1e-6
    dtype: jnp.dtype = jnp.float32
    
    @fnn.compact
    def __call__(self, x):
        return fnn.LayerNorm(epsilon=self.epsilon, dtype=self.dtype)(x)

def main():
    parser = argparse.ArgumentParser(description='SPU LayerNorm Network Benchmark')
    parser.add_argument('-c', '--config', default='examples/python/conf/2pc.json')
    parser.add_argument('--batch', type=int, default=1, help='Batch size')
    parser.add_argument('--seq_len', type=int, default=128, help='Sequence length')
    parser.add_argument('--hidden', type=int, default=768, help='Hidden dimension')
    parser.add_argument('--loop', type=int, default=11, help='Number of benchmark iterations')
    args = parser.parse_args()

    print(f"Loading config from: {args.config}")
    with open(args.config, 'r') as f:
        conf = json.load(f)

    # Initialize the SPU cluster
    print("Initializing SPU cluster...")
    ppd.init(conf['nodes'], conf['devices'])

    # Generate synthetic data
    # Typical input for Transformer LayerNorm: [batch, seq_len, hidden]
    input_shape = (args.batch, args.seq_len, args.hidden)
    print(f"Generating random input data {input_shape}...")
    np.random.seed(42)
    x_np = np.random.randn(*input_shape).astype(np.float32)

    # Initialize Flax Model
    model = LayerNormModel()
    key = jax.random.PRNGKey(0)
    variables = model.init(key, jnp.ones(input_shape))
    
    # Compiler options
    copts = spu_pb2.CompilerOptions()
    # LayerNorm involves division (by sqrt of variance), broadcast optimization helps
    copts.enable_optimize_denominator_with_broadcast = True

    # Transfer data
    print("Transferring data...")
    x_p1 = ppd.device('P1')(lambda t: t)(x_np)
    params_p2 = ppd.device('P2')(lambda t: t)(variables)

    def model_forward(params, x):
        return model.apply(params, x)

    # Compile/Warmup
    print("Compiling and warming up on SPU...")
    # Note: First run triggers compilation
    y_spu = ppd.device('SPU')(model_forward, copts=copts)(params_p2, x_p1)
    _ = ppd.get(y_spu)

    # Benchmark Loop
    print(f"Starting benchmark ({args.loop} iterations)...")
    latencies = []
    
    for i in range(args.loop):
        start = time.time()
        
        # Schedule SPU task
        y_spu = ppd.device('SPU')(model_forward, copts=copts)(params_p2, x_p1)
        
        # Fetch result to synchronize and measure end-to-end time
        _ = ppd.get(y_spu)
        
        end = time.time()
        latencies.append(end - start)
        print(f"Iter {i+1}/{args.loop}: {latencies[-1]:.4f}s")

    avg_latency = sum(latencies) / len(latencies)
    total_elements = np.prod(input_shape)
    print(f"\nBenchmark Results:")
    print(f"Input Shape: {input_shape}")
    print(f"Avg Latency: {avg_latency:.4f} seconds")
    print(f"Throughput: {total_elements / avg_latency:.2f} elements/sec")

    # Correctness Check
    print("\nVerifying correctness...")
    y_np = ppd.get(y_spu)
    # Run on CPU for ground truth
    expected = model.apply(variables, x_np)
    
    # Allow for some error due to fixed-point precision
    diff = np.max(np.abs(y_np - expected))
    
    print(f"Max absolute difference vs CPU: {diff}")
    
    # LayerNorm can be sensitive, threshold might need adjustment
    if diff > 1e-2:
        print("WARNING: Difference is large, check precision settings.")
    else:
        print("Correctness verified.")

if __name__ == '__main__':
    main()
