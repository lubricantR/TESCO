# Examples

This directory contains examples demonstrating how to use SPU to write privacy-preserving machine learning programs.
