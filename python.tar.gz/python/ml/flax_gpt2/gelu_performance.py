# Copyright 2023 Ant Group Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Start nodes.
# > bazel run -c opt //examples/python/utils:nodectl -- --config `pwd`/examples/python/conf/2pc.json up
#
# Run this example script.
# > bazel run -c opt //examples/python/ml/flax_gpt2:gelu_performance_test -- --config `pwd`/examples/python/conf/2pc.json

import argparse
import json
import time

import jax
import jax.numpy as jnp
import numpy as np

import spu.intrinsic as intrinsic
import spu.spu_pb2 as spu_pb2
import spu.utils.distributed as ppd

copts = spu_pb2.CompilerOptions()
copts.enable_optimize_denominator_with_broadcast = True

parser = argparse.ArgumentParser(description='GELU performance test on SPU')
parser.add_argument("-c", "--config", default="examples/python/ml/flax_gpt2/2pc.json")
parser.add_argument("-s", "--size", type=int, default=1024, help='Input tensor size')
parser.add_argument("-i", "--iterations", type=int, default=100, help='Number of iterations')
args = parser.parse_args()

with open(args.config, 'r') as file:
    conf = json.load(file)

ppd.init(conf["nodes"], conf["devices"])

def gelu_cpu(x):
    """Standard GELU implementation for CPU"""
    return 0.5 * x * (1.0 + jnp.tanh(jnp.sqrt(2.0 / jnp.pi) * (x + 0.044715 * jnp.power(x, 3))))

def gelu_spu(x):
    # Force cast to float to ensure FXP representation for the intrinsic
    x = jnp.add(x, 0.0)
    return intrinsic.spu_gelu(x)

def benchmark_gelu_cpu(input_data, iterations=100):
    """Benchmark GELU on CPU"""
    print(f"Running GELU on CPU with input size {input_data.shape}...")
    
    # Warm up
    for _ in range(10):
        _ = gelu_cpu(input_data)
    
    # Benchmark
    start_time = time.time()
    for _ in range(iterations):
        result = gelu_cpu(input_data)
    _ = result.block_until_ready()  # Ensure computation completes
    end_time = time.time()
    
    cpu_time = (end_time - start_time) / iterations
    print(f"CPU average time per iteration: {cpu_time:.6f} seconds")
    return cpu_time

def benchmark_gelu_spu(input_data, iterations=100):
    """Benchmark GELU on SPU"""
    print(f"Running GELU on SPU with input size {input_data.shape}...")
    
    # Convert to SPU device
    spu_input = ppd.device("P1")(lambda x: x)(input_data)
    # Ensure argument visibility is secret on SPU
    # We multiply by 1.0 to force the value into the FXP domain if it isn't already
    spu_input_sec = ppd.device("SPU")(lambda x: jnp.multiply(x, 1.0), copts=copts)(spu_input)
    print(f"[DEBUG] SPU input visibility (expected secret): {getattr(spu_input_sec, 'vtype', None)}")
    ir_text = ppd.device("SPU")(gelu_spu, copts=copts).dump_ir(spu_input_sec)
    print("[DEBUG] PPHLO contains custom call:", "spu.gelu" in ir_text)
    
    # Warm up
    for _ in range(10):
        _ = ppd.device("SPU")(gelu_spu, copts=copts)(spu_input_sec)
    
    # Benchmark
    start_time = time.time()
    for _ in range(iterations):
        spu_result = ppd.device("SPU")(gelu_spu, copts=copts)(spu_input_sec)
    result = ppd.get(spu_result)  # Ensure computation completes
    end_time = time.time()
    
    spu_time = (end_time - start_time) / iterations
    print(f"SPU average time per iteration: {spu_time:.6f} seconds")
    return spu_time

def benchmark_gelu_comparison():
    """Compare GELU performance between CPU and SPU"""
    print("=" * 60)
    print("GELU Performance Comparison Test")
    print("=" * 60)
    
    # Create test data
    input_size = args.size
    input_data = jnp.array(np.random.randn(input_size, input_size).astype(np.float32))
    
    print(f"Test configuration:")
    print(f"  - Input tensor size: {input_size}x{input_size}")
    print(f"  - Number of iterations: {args.iterations}")
    print(f"  - Data type: float32")
    print()
    
    # Benchmark CPU
    cpu_time = benchmark_gelu_cpu(input_data, args.iterations)
    
    # Benchmark SPU
    spu_time = benchmark_gelu_spu(input_data, args.iterations)
    
    # Compare results
    speedup = cpu_time / spu_time if spu_time > 0 else float('inf')
    
    print("\n" + "=" * 60)
    print("Performance Summary:")
    print("=" * 60)
    print(f"CPU average time: {cpu_time:.6f} seconds")
    print(f"SPU average time: {spu_time:.6f} seconds")
    print(f"Speedup (CPU/SPU): {speedup:.2f}x")
    
    if speedup > 1.0:
        print(f"✓ SPU is {speedup:.2f}x faster than CPU")
    else:
        print(f"✗ CPU is {1/speedup:.2f}x faster than SPU")
    
    print("=" * 60)

def test_gelu_accuracy():
    """Test GELU accuracy between CPU and SPU implementations"""
    print("\nTesting GELU accuracy...")
    
    # Create test data
    test_input = jnp.array(np.linspace(-3.0, 3.0, 100).astype(np.float32))
    
    # CPU result
    cpu_result = gelu_cpu(test_input)
    
    # SPU result
    spu_input = ppd.device("P1")(lambda x: x)(test_input)
    spu_input_sec = ppd.device("SPU")(lambda x: x, copts=copts)(spu_input)
    print(f"[DEBUG] Accuracy input visibility (expected secret): {getattr(spu_input_sec, 'vtype', None)}")
    spu_result = ppd.device("SPU")(gelu_spu, copts=copts)(spu_input_sec)
    spu_result = ppd.get(spu_result)
    
    # Calculate error
    max_abs_error = jnp.max(jnp.abs(cpu_result - spu_result))
    mean_abs_error = jnp.mean(jnp.abs(cpu_result - spu_result))
    
    print(f"Maximum absolute error: {max_abs_error:.2e}")
    print(f"Mean absolute error: {mean_abs_error:.2e}")
    
    if max_abs_error < 1e-5:
        print("✓ GELU implementations are numerically equivalent")
    else:
        print("⚠ Warning: GELU implementations have significant differences")

if __name__ == '__main__':
    # Run performance benchmark
    benchmark_gelu_comparison()
    
    # Run accuracy test
    test_gelu_accuracy()
