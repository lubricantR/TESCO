import numpy as np

# --- 配置 ---
BUFFER_SIZE = 1_000_0
DTYPE = np.float32
OUTPUT_FILE_PATTERN = "gpt2{:03d}.dat"

# --- 状态 ---
buffer = np.empty(BUFFER_SIZE, dtype=DTYPE)
index = 0
file_count = 0

def collect_tensor(t):
    """收集张量值，满了就写入文件"""
    global index, file_count
    flat_vals = np.asarray(t, dtype=DTYPE).flatten()
    
    if index + len(flat_vals) > BUFFER_SIZE:
        if index > 0:
            buffer[:index].tofile(OUTPUT_FILE_PATTERN.format(file_count))
            file_count += 1
            print(f"Saved part {file_count-1}") # 添加提示
        index = 0

    if len(flat_vals) >= BUFFER_SIZE:
         # 如果单个张量就很大，直接存
         flat_vals.tofile(OUTPUT_FILE_PATTERN.format(file_count))
         file_count += 1
         print(f"Directly saved large tensor to part {file_count-1}") # 添加提示
    else:
        buffer[index:index+len(flat_vals)] = flat_vals
        index += len(flat_vals)
        if index >= BUFFER_SIZE:
            buffer.tofile(OUTPUT_FILE_PATTERN.format(file_count))
            file_count += 1
            print(f"Saved part {file_count-1}") # 添加提示
            index = 0

# --- 使用 ---
# 在程序开始时 (可选，第一次调用 collect_tensor 时 buffer 已定义)
# index = 0; file_count = 0 

# 在你的循环里
# for tensor in your_tensors:
#     collect_tensor(tensor)

# 程序结束前，保存最后一部分 (如果有的话)
# if index > 0:
#     buffer[:index].tofile(OUTPUT_FILE_PATTERN.format(file_count))
#     print(f"Saved final part {file_count}")