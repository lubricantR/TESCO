export TASK_NAME=qnli
export GLOO_SOCKET_IFNAME=tdx-tap0
export TRANSFORMERS_OFFLINE=1
export HF_HUB_OFFLINE=1

limitipspeedcalaulatecomm.sh 400000 0 -- python launchp1.py --model_name_or_path andeskyl/bert-base-cased-$TASK_NAME --task_name $TASK_NAME --len_data 64   --max_length 64 --per_device_eval_batch_size 1 --output_dir eval_private/$TASK_NAME/1 &


python launchp0.py --model_name_or_path andeskyl/bert-base-cased-$TASK_NAME --task_name $TASK_NAME --len_data 64   --max_length 64 --per_device_eval_batch_size 1 --output_dir eval_private/$TASK_NAME/1 
wait