export TASK_NAME=qnli

#limitipspeed.sh 10000000 0 -- 
python launchp1.py --model_name_or_path andeskyl/bert-base-cased-$TASK_NAME --task_name $TASK_NAME --len_data 128   --max_length 128 --per_device_eval_batch_size 1 --output_dir eval_private/$TASK_NAME/1 &
#python launchp1.py --model_type=gpt2 --model_name_or_path=openai-community/gpt2 --len_data 64 --length 1 &

python launchteep2.py &
python launchp0.py --model_name_or_path andeskyl/bert-base-cased-$TASK_NAME --task_name $TASK_NAME --len_data 128   --max_length 128 --per_device_eval_batch_size 1 --output_dir eval_private/$TASK_NAME/1 
wait