python launchp0.py --model_name_or_path google/vit-base-patch16-224 --max_eval_samples 1 --seed 42 &
limitipspeedcalaulatecomm.sh 10000000 0 -- python launchp1.py --model_name_or_path google/vit-base-patch16-224 --max_eval_samples 1 --seed 42 &
#python launchp1.py --model_name_or_path google/vit-base-patch16-224 --max_eval_samples 1 --seed 42 &
python launchteep2.py 
wait