# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 21:51:28 2025

@author: Administrator
"""

from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch
import math
from datasets import load_dataset
device="cuda"
def logits_to_loss(logits, labels, attention_mask=None):
    """
    从 logits 计算交叉熵损失，用于自回归语言建模。
    
    参数:
        logits: torch.Tensor, 形状 (batch_size, sequence_length, vocab_size)，模型输出的未归一化分数
        labels: torch.Tensor, 形状 (batch_size, sequence_length)，目标 token ID
        attention_mask: torch.Tensor, 形状 (batch_size, sequence_length)，1 表示有效 token，0 表示填充（可选）
    
    返回:
        loss: float，平均交叉熵损失
    """
    # 移位 logits 和 labels 以匹配自回归任务（预测下一个词）
    shift_logits = logits[:, :-1, :].contiguous()  # 忽略最后一个 token 的预测
    shift_labels = labels[:, 1:].contiguous()      # 忽略第一个 token
    
    # 如果提供了 attention_mask，相应移位
    if attention_mask is not None:
        shift_attention_mask = attention_mask[:, 1:].contiguous()
        # 将无效 token 的标签设为 -100（CrossEntropyLoss 的忽略索引）
        shift_labels = shift_labels.masked_fill(shift_attention_mask == 0, -100)
    
    # 计算交叉熵损失
    loss_fn = torch.nn.CrossEntropyLoss(reduction='mean', ignore_index=-100)
    loss = loss_fn(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
    
    return loss.item()
def calculate_dataset_perplexity(dataset, model_name='openai-community/gpt2', max_length=64):
    tokenizer = GPT2Tokenizer.from_pretrained(model_name)
    model = GPT2LMHeadModel.from_pretrained(model_name).to(device)
    model.eval()
    
    total_loss = 0.0
    total_tokens = 0
    
    for example in dataset:
        text = example["text"].strip()
        if not text:  # 跳过空文本
            continue
        encodings = tokenizer(text, return_tensors="pt", max_length=max_length, truncation=True)
        input_ids = encodings.input_ids.to(device)
        attention_mask = encodings.attention_mask.to(device)
        
        with torch.no_grad():
            outputs = model(input_ids)
            loss=logits_to_loss(outputs.logits, input_ids)
            print('loss',loss)

            
            if loss is not None and not math.isnan(loss):  # 确保损失有效
                total_loss += loss * input_ids.size(1)
                total_tokens += input_ids.size(1)
    
    if total_tokens == 0:
        return float("inf")  # 防止除零
    avg_loss = total_loss / total_tokens

    return avg_loss

# 加载 WikiText-2 测试集
import os
os.environ["HF_DATASETS_OFFLINE"] = "1"
dataset = load_dataset("wikitext", "wikitext-2-v1", split="test")
try:
    perplexity = calculate_dataset_perplexity(dataset)
    print(f"Average Perplexity on WikiText-2 (max_length=128): {perplexity:.2f}")
except Exception as e:
    print(f"An error occurred: {e}")