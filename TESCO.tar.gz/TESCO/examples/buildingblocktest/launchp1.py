
import argparse
import logging
import torch

import datasets
import crypten as ct
from crypten.config import cfg
from multiprocess_launcher import MultiProcessLauncher

from tqdm.auto import tqdm

import transformers
from transformers import AutoConfig, AutoModelForImageClassification
from transformers.utils import check_min_version
from transformers.utils.versions import require_version
import os
import crypten
import crypten.communicator as comm
# Will error if the minimal version of Transformers is not installed. Remove at your own risks.
from crypten.mpc.rhyltz import rhy3mul,rhy3waitall1
from crypten.mpc import MPCTensor


import uuid
from run_image_classification_private import main

if __name__ == "__main__":
    
    
    
    env = os.environ
    env["WORLD_SIZE"] = '2'
       
    INIT_METHOD = "tcp://127.0.0.1:29500"
    env["RENDEZVOUS"] = INIT_METHOD
    os.environ["RANK"] = '1'
    crypten.init()
    main()



