python launchp0.py &
limitipspeedcalaulatecomm.sh 1000000 0 -- python launchp1.py &  
python launchteep2.py 
wait