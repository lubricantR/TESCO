import torch

def topn_overlap(a: torch.Tensor, b: torch.Tensor, n: int) -> int:
    """
    计算两个向量的 Top-N 元素中有多少个是相同的（按值排序）。

    Args:
        a (torch.Tensor): 向量 A（1D Tensor）
        b (torch.Tensor): 向量 B（1D Tensor）
        n (int): Top-N 范围

    Returns:
        int: Top-N 元素中相同的元素数量
    """
    if a.ndim != 1 or b.ndim != 1:
        raise ValueError("Input tensors must be 1D")
    if len(a) != len(b):
        raise ValueError("Input tensors must have the same length")
    if n > len(a):
        raise ValueError("n cannot be larger than vector length")

    # 取前 N 个最大值的索引
    topn_a = torch.topk(a, n).indices
    topn_b = torch.topk(b, n).indices

    # 转为 set 做交集
    overlap = set(topn_a.tolist()) & set(topn_b.tolist())
    return len(overlap)
