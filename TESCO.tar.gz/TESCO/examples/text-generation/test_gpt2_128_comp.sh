python run_generation_private.py \
  --model_type=gpt2 \
  --model_name_or_path=openai-community/gpt2 \
  --len_data 128 \
  --comp \
  --length 1