# coding=utf-8
# Modified by SHAFT's team: Private Text Classification on ImageNet-1k.
# 
# Copyright 2022 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Finetuning any 🤗 Transformers model for image classification leveraging 🤗 Accelerate."""

import argparse
import logging
import torch

import datasets
import crypten as ct
from crypten.config import cfg
from multiprocess_launcher import MultiProcessLauncher

from tqdm.auto import tqdm

import transformers
from transformers import AutoConfig, AutoModelForImageClassification
from transformers.utils import check_min_version
from transformers.utils.versions import require_version
import os
import crypten
import crypten.communicator as comm
# Will error if the minimal version of Transformers is not installed. Remove at your own risks.
from crypten.mpc.rhyltz import rhy3mul,rhy3waitall1
from crypten.mpc import MPCTensor

#import torch.multiprocessing as mp

import multiprocessing as mp

import uuid
from run_generation_private import main,parse_args
import time
def p0receiver(q):
    print('starting receiver')
    import torch.distributed as dist
    import queue
    if cfg.r3fourth==0:
        return
    env = os.environ
    env["WORLD_SIZE"] = '2'
       
    INIT_METHOD =  "tcp://127.0.0.1:29500"
    env["RENDEZVOUS"] = INIT_METHOD
    os.environ["RANK"] = '3'
    print('starting init')
    crypten.init()
    records=torch.load('r3fourthrecords.bin')
    recvtensors=[];recvi=0
    for x in records:
        t=torch.empty(x[0],dtype=x[1])
        #t.share_memory_()
        recvtensors.append(t)
    waithandles=queue.Queue()
    sendhandles=queue.Queue()
    start = time.perf_counter()
    sendbyte=0
    for i in range(5):
        waithandles.put(dist.irecv(recvtensors[recvi],1));recvi+=1;
    waiti=0
    first=0
    while not waithandles.empty():
        #print('wait s',recvtensors[waiti].shape)
        waithandles.get().wait()
        #recvtensors[waiti].share_memory_()
        #print('put s',recvtensors[waiti].shape)
        #q.put(recvtensors[waiti]);waiti+=1
        sendhandles.put( dist.isend(recvtensors[waiti],0))
        sendbyte+=recvtensors[waiti].numel()*recvtensors[waiti].element_size()
        waiti+=1
        #print('put e')
        if recvi<len(records):
            waithandles.put(dist.irecv(recvtensors[recvi],1));recvi+=1;
        if first==0:
            first=1;start = time.perf_counter()
    end = time.perf_counter()
    print(f'p3 recv {end-start}s {sendbyte}B')
    while not sendhandles.empty():
        sendhandles.get().wait()


if __name__ == "__main__":
    mp.set_start_method("spawn")
    mg=mp.Manager()
    q = mg.Queue();     print('beforpstart');crypten.r3fourth_queue=q
    p = mp.Process(target=p0receiver, args=(q,))
    
    p.start()
    args = parse_args()
    
    env = os.environ
    env["WORLD_SIZE"] = '2'
       
    INIT_METHOD =  "tcp://127.0.0.1:29500"
    env["RENDEZVOUS"] = INIT_METHOD
    os.environ["RANK"] = '0'
    crypten.init()
    
    main()
    
    crypten.rhy3time.r3timeprintall()
    if cfg.r3fourthrecording==1:
        torch.save(crypten.r3fourthrecords,'r3fourthrecords.bin')

