python launchp0.py &
trickle -d 125000 -u 125000 python launchp1.py &  
python launchteep2.py 
wait