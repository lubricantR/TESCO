# coding=utf-8
# Modified by SHAFT's team: Private Text Classification on ImageNet-1k.
# 
# Copyright 2022 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Finetuning any 🤗 Transformers model for image classification leveraging 🤗 Accelerate."""

import argparse
import logging
import torch

import datasets
import crypten as ct
from crypten.config import cfg
from multiprocess_launcher import MultiProcessLauncher

from tqdm.auto import tqdm

import transformers
from transformers import AutoConfig, AutoModelForImageClassification
from transformers.utils import check_min_version
from transformers.utils.versions import require_version
import os
import crypten.communicator as comm
# Will error if the minimal version of Transformers is not installed. Remove at your own risks.
from crypten.mpc.rhyltz import rhy3mul,rhy3waitall1
from crypten.mpc import MPCTensor


import code
from crypten.mpc.rhyltz import rhy3waitall1


import time
from crypten.rhy3time import *
import atexit
def r3timeonexit():
    r3timeprintall()
def main():
    atexit.register(r3timeprintall)
    
    
    #print("rank=",os.environ["RANK"])

    
    if os.environ["RANK"]=='1':
        device = "cuda"
    else:
        device = "cuda"
    
    ct.init()
    
    testdim=1024
    model=torch.nn.ReLU();dummy_input=torch.ones(100)
    private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
    torch.manual_seed(3)
    #om1=torch.tensor([[1,2,3,4,5]])
    #om1=torch.randn([12,128,128]).to(device)
    om1=torch.randn([1024,1024]).to(device)
    m1=ct.cryptensor(om1).to(device); 
    
    if os.environ["RANK"]=='0':

        None
    for i in range(2):

        #z=private_model(m1)
        if os.environ["RANK"]=='0':
            with r3namedtime('runningtime***'):
                #z=m1.softmax(1)
                z=private_model(m1)
        else:
            #z=m1.softmax(1)
            z=private_model(m1)

       
        #print(f'p{os.environ["RANK"]}{i}')

        
    print(os.environ["RANK"],'compute end')
    rhy3waitall1()
    #print((z.get_plain_text()-torch.nn.functional.relu(om1)).abs().mean())
    print((z.get_plain_text()-torch.softmax(om1,dim=1)).abs().mean())
        

if __name__ == "__main__":
    
    args = parse_args()
    
    if args.comp:
        # run without communication
        with cfg.temp_override({"cost.estimate_cost": True, "cost.estimate_mode": "comp"}):
            main()
    else:
        # run with communication
        launcher = MultiProcessLauncher(2, main)
        launcher.start()
        launcher.join()
        launcher.terminate()
