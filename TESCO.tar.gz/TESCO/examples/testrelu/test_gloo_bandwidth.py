# test_gloo_bandwidth.py
import os
import torch
import torch.distributed as dist
import argparse
import datetime
import time

def run(rank, world_size, tensor_mb, num_warmup, num_iters):
    print(f"[Rank {rank}] Initializing process group with Gloo (CPU)...")
    dist.init_process_group(
        backend="gloo",
        init_method="env://",
        rank=rank,
        world_size=world_size,
        timeout=datetime.timedelta(seconds=90),
    )

    # 创建 float32 张量（每个元素 4 字节）
    num_elements = (tensor_mb * 1024 * 1024) // 4
    tensor = torch.randn(num_elements, dtype=torch.float32)  # CPU tensor

    print(f"[Rank {rank}] Tensor size: {tensor.numel() * 4 / (1024**2):.2f} MB")

    # Warmup iterations (not timed)
    for _ in range(num_warmup):
        tmp = tensor.clone()
        dist.all_reduce(tmp, op=dist.ReduceOp.SUM)

    # Barrier to synchronize all ranks before timing
    dist.barrier()

    # Timed iterations
    start_time = time.perf_counter()
    for _ in range(num_iters):
        tmp = tensor.clone()
        dist.all_reduce(tmp, op=dist.ReduceOp.SUM)
    end_time = time.perf_counter()

    total_time = end_time - start_time
    avg_time_per_iter = total_time / num_iters

    # Bandwidth calculation
    data_bytes = tensor.numel() * 4  # float32
    bandwidth_gbps = (data_bytes / avg_time_per_iter) / (1024**3)  # GB/s

    print(f"[Rank {rank}] Avg all_reduce time: {avg_time_per_iter * 1000:.3f} ms")
    print(f"[Rank {rank}] Estimated bandwidth: {bandwidth_gbps:.3f} GB/s")

    dist.destroy_process_group()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Measure Gloo all_reduce bandwidth on CPU")
    parser.add_argument("--rank", type=int, required=True, help="Global rank (e.g., 0 or 1)")
    parser.add_argument("--world-size", type=int, default=2, help="Total number of processes")
    parser.add_argument("--master-addr", type=str, required=True, help="IP address of rank 0")
    parser.add_argument("--master-port", type=int, default=29500, help="Port for communication")
    parser.add_argument("--tensor-mb", type=int, default=128, help="Tensor size in MB (default: 128)")
    parser.add_argument("--warmup", type=int, default=5, help="Number of warmup iterations")
    parser.add_argument("--iters", type=int, default=20, help="Number of timed iterations")

    args = parser.parse_args()

    # Set environment variables for Gloo
    os.environ["MASTER_ADDR"] = args.master_addr
    os.environ["MASTER_PORT"] = str(args.master_port)
    os.environ["RANK"] = str(args.rank)
    os.environ["WORLD_SIZE"] = str(args.world_size)

    run(
        rank=args.rank,
        world_size=args.world_size,
        tensor_mb=args.tensor_mb,
        num_warmup=args.warmup,
        num_iters=args.iters
    )