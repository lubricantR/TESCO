# coding=utf-8
# Modified by SHAFT's team: Private Text Classification on ImageNet-1k.
# 
# Copyright 2022 The HuggingFace Inc. team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Finetuning any 🤗 Transformers model for image classification leveraging 🤗 Accelerate."""

import argparse
import logging
import torch

import datasets
import crypten as ct
from crypten.config import cfg
from multiprocess_launcher import MultiProcessLauncher

from tqdm.auto import tqdm

import transformers
from transformers import AutoConfig, AutoModelForImageClassification
from transformers.utils import check_min_version
from transformers.utils.versions import require_version
import os
import crypten.communicator as comm
# Will error if the minimal version of Transformers is not installed. Remove at your own risks.
from crypten.mpc.rhyltz import rhy3mul,rhy3waitall1
from crypten.mpc import MPCTensor
check_min_version("4.42.0.dev0")

require_version("datasets>=2.0.0", "To fix: pip install -r examples/pytorch/image-classification/requirements.txt")
import code
from crypten.mpc.rhyltz import rhy3waitall1
def parse_args():
    parser = argparse.ArgumentParser(description="Fine-tune a Transformers model on an image classification dataset")
    parser.add_argument(
        "--comp",
        action="store_true",
        help="If passed, estimate computation time (without communication).",
    )
    parser.add_argument("--validation_dir", type=str, default=None, help="A folder containing the validation data.")
    parser.add_argument(
        "--max_eval_samples",
        type=int,
        default=None,
        help=(
            "For debugging purposes or quicker training, truncate the number of evaluation examples to this "
            "value if set."
        ),
    )
    parser.add_argument(
        "--model_name_or_path",
        type=str,
        help="Path to pretrained model or model identifier from huggingface.co/models.",
        default="google/vit-base-patch16-224-in21k",
    )
    parser.add_argument("--seed", type=int, default=None, help="A seed for reproducible result.")
    args = parser.parse_args()

    return args

import time
from crypten.rhy3time import *
import atexit
def r3timeonexit():
    r3timeprintall()
def main():
    atexit.register(r3timeprintall)
    args = parse_args()
    print(args)
    #print("rank=",os.environ["RANK"])

    
    if os.environ["RANK"]=='1':
        device = "cuda"
    else:
        device = "cuda"
    
    ct.init()
    '''rank=int(os.environ["RANK"])
    msg=torch.ones((5))
    if rank==1:
        msg*=5;
        comm.get().send(msg,0)
    else:
        msg=comm.get().recv(msg,1)
    print(f'rank{rank} {msg}')'''  
    '''
    model=torch.nn.Linear(3,2);
    dummy_input = torch.ones([1, 3])
    private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)

    model.eval()
    for _ in range(args.max_eval_samples):
        input = torch.ones([1, 3], device=device)*1
        input_enc = ct.cryptensor(input).to(device)
        with ct.no_grad():
            print(private_model(input_enc).get_plain_text())
            #print(input_enc.get_plain_text())
            #print(input_enc)
''' 
    torch.manual_seed(3)
    testdim=1024
    om1=torch.randn((1,128,768)).to(device);
    dummy_input = om1

    model=torch.nn.Linear(768,128)#model=torch.nn.LayerNorm(768)#model=torch.nn.GELU();
    model=model.to(device)
    private_model = ct.nn.from_pytorch(model, dummy_input).encrypt().to(device)
    
    plainresult=model(om1)
    m1=ct.cryptensor(om1).to(device);    
    
   
    for i in range(10):
        if os.environ["RANK"]=='0':
            with r3namedtime('runningtime***'):
                #z=m1.softmax(1)
                z=private_model(m1)
        else:
            #z=m1.softmax(1)
            z=private_model(m1)
        
       
        print(f'p{os.environ["RANK"]}{i}')
       
        
    print(os.environ["RANK"],'compute end')
    rhy3waitall1()
    print((z.get_plain_text()-plainresult).abs().mean())
        

if __name__ == "__main__":
    
    args = parse_args()
    
    if args.comp:
        # run without communication
        with cfg.temp_override({"cost.estimate_cost": True, "cost.estimate_mode": "comp"}):
            main()
    else:
        # run with communication
        launcher = MultiProcessLauncher(2, main)
        launcher.start()
        launcher.join()
        launcher.terminate()
