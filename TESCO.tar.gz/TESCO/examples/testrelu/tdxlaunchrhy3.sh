
export GLOO_SOCKET_IFNAME=tdx-tap0 
python launchp0.py --model_name_or_path google/vit-base-patch16-224 --max_eval_samples 1 --seed 42 &
limitipspeedcalaulatecomm.sh 400000 0 -- python launchp1.py --model_name_or_path google/vit-base-patch16-224 --max_eval_samples 1 --seed 42 &
#GLOO_SOCKET_IFNAME=tdx-tap0 python launchp1.py --model_name_or_path google/vit-base-patch16-224 --max_eval_samples 1 --seed 42 &

wait