tc qdisc del dev lo root
tc qdisc add dev lo root netem delay $1ms rate $2mbit